<!DOCTYPE html>
<html>
<head><!-- CDN hosted by Cachefly -->
    <script src=../../Views/jquery/jquery_v152.js></script>
<script src="tinymce.min.js"></script>
<script type="text/javascript">
tinymce.init({
    selector: "textarea",
    paste_data_images: true,
    plugins: [
        "advlist autolink lists link image charmap print preview anchor",
        "searchreplace visualblocks code fullscreen",
        "insertdatetime media table contextmenu paste"
    ],
    toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image"
});
</script>

<form method="post" action="somepage">
    <textarea name="content"  rows="25"style="width:100%"></textarea>
</form>
</body>
</html>