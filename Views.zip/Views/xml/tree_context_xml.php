<?php

header("Content-type:text/xml");
print('<menu id="0" >');
print('<item text="Add"  img="../imgs/add.png"  id="main_add_dir">');
print('<item text="Add Department"  img="../imgs/add.png"  id="add_root"/>');
print('<item text="Add members"  img="../imgs/add.png"  id="add_sub"/>');

print('</item>');
print('<item text="Rename member"  img="../imgs/edit.png"  id="rename"/>');
print('<item text="Delete member"  img="../imgs/delete.png"  id="delete"/>');
print('</menu>');
?>