
        scheduler.locale.labels.section_custom="Section";
	scheduler.config.details_on_create=true;
        scheduler.config.details_on_dblclick=true;
        scheduler.config.xml_date="%Y-%m-%d %H:%i";
        scheduler.locale.labels.unit_tab = "Day"
        scheduler.xy.min_event_height = 1;
           
        
        scheduler.config.first_hour=7;         

        scheduler.config.lightbox.sections=[                        
                        {name:"description", height:300, map_to:"text", type:"textarea" ,id:"scheduler_textarea", focus:true},
                        {name:"Ref Number", height:20, type:"textarea", map_to:"tag_id"},
                        {name:"custom", height:23, type:"select", options:sections, map_to:"employee_id" },
                        {name:"time", height:72, type:"time", map_to:"auto"}
                        ];
        
        scheduler.createUnitsView({
        name:"unit",
        property:"employee_id", 
        list:sections
        });
        
        scheduler.config.multi_day = false;        
      
        var step = 15;
        var format = scheduler.date.date_to_str("%H:%i");		
        scheduler.config.hour_size_px=(60/step)*22;

        scheduler.templates.hour_scale = function(date){
                html="";
                for (var i=0; i<15/step; i++){
                        html+="<div style='height:22px;line-height:22px;'>"+format(date)+"</div>";
                        date = scheduler.date.add(date,step,"minute");
                }
                return html;
        }

        scheduler.config.xml_date="%Y-%m-%d %H:%i";       
        
        
        scheduler.init('scheduler_here',null,"unit");
        
        scheduler.attachEvent("onBeforeLightbox", function (id){
            var mode = scheduler.getState().mode;
            if(mode == "week" || mode == "month"){
                 $.get("Controller/data.php?action=5&id="+emp,function(data) 
                  { 
                   scheduler.formSection('custom').setValue(data.emp);
                  },"json");
            }
            return true;
        });

        
        scheduler.attachEvent("onLightbox", function (id){
                var myFormDetail = scheduler.formSection('description').getValue();
      
                tinymce.init({
                selector: "#scheduler_textarea",
                plugins: "textcolor",
                toolbar: "forecolor backcolor bold  strikethrough",
                auto_focus: "scheduler_textarea",
                setup: function(editor) {
                editor.on('change', function(e) { 
                    scheduler.formSection('description').setValue(this.getContent());               
                    });
                editor.on('keyup', function(e) { 
                    scheduler.formSection('description').setValue(this.getContent());
                  });
                }
                
            });
            
           // $( document ).ready(function() { 
                if(tinymce.activeEditor){                 
                
                tinymce.activeEditor.setContent(myFormDetail, {format : 'raw'});
                tinymce.activeEditor.selection.select(tinyMCE.activeEditor.getBody(), true);
                tinymce.activeEditor.selection.collapse(false);
                tinymce.activeEditor.focus() 
                }
          
            //});            
          return true;
         }); 
         
         
         scheduler.attachEvent("onViewChange", function(new_mode,new_date){ 
                adjustTop();
             if(new_mode == "unit"){             
               if(parent.myEmployeeCombo.getSelectedValue()){              
                scheduler.load("Controller/data.php?id="+branch,function(){
                adjustTop();      
               }); 
               }else{                 
                scheduler.load("Controller/data.php?id="+branch,function(){
                adjustTop();      
                }); 
              }   
             }
        return true;
        });

        
        scheduler.setLoadMode("unit");  
        scheduler.config.show_loading=true;
	var dp = new dataProcessor("Controller/data.php?action=10&id="+branch);
        dp.init(scheduler);
        dp.attachEvent("onAfterUpdate", function (sid,action,tid,xml_node)
            {       
                var uId = "";
                if(uId){
                  uId = getCookie('userlggd');  
                }else{
                   uId = emp; 
                }            
                $.get("Controller/author.php?action=2&event_id="+tid+"&userId="+uId,function(data) 
                    {  
                    },'json');
            });
   
   scheduler.clearAll();
   scheduler.setCurrentView(new Date(), "unit");       
   
   _Layout.cells('a').attachObject('scheduler_here');
   _Layout.attachEvent("onExpand", function(name){
       if(name == 'b'){     
          scheduler.setCurrentView(new Date(), "unit");
              adjustTop();
       }
   });
  _Layout.attachEvent("onCollapse", function(name){
       if(name == 'b'){     
          scheduler.setCurrentView(new Date(), "unit");
          adjustTop();
       }
   });
   
   function adjustTop(){
       $("#sHeader").css("top", "0px");
       $("#sBody").css("top", "22px");      
      // $(".dhx_cal_data").css("overflow-y", "hidden");
      
   }
   
   function employeeNav(value){
       //load operations
        scheduler.clearAll();                 
        scheduler.load("Controller/data.php?id="+branch);

        if(gridTree){
         schedulerLayout.cells("a").progressOn();
         gridTree.clearAndLoad('Controller/openTasks.php?uid='+value,function(){
         schedulerLayout.cells("a").progressOff();
         gridTree.expandAll();
         });    
       }   
   }
   
  function newTask(){
      Date.prototype.addHours= function(h){
            this.setHours(this.getHours()+h);
            return this;
        }    
       var myDate = new Date().addHours(2);

      $.get("Controller/data.php?action=5&id="+emp+"&dt="+myDate,function(data) 
            { 
                var eventId = scheduler.addEvent({
                start_date: new Date(),
                end_date: data.tend,
                text:   "",
                employee_id: data.emp
            });
           scheduler.showLightbox(eventId);           
           
         },"json");      
  }
  
function changeScheduleHeader(){
      var calDate = document.getElementsByClassName("dhx_cal_date");
      dttext = calDate[0].innerHTML;
      //loadTreeGrid(dttext); 
      return calDate[0].innerHTML;
  }
function calPrevious(){
      var btnNext = document.getElementsByClassName("dhx_cal_prev_button"); 
      scheduler.setCurrentView(scheduler.date.add(scheduler.date[scheduler._mode + "_start"](scheduler._date),  -1, scheduler._mode));     
      parent.changeScheduleHeader();
      var calDate = document.getElementsByClassName("dhx_cal_date");
      dttext = calDate[0].innerHTML;
      loadTreeGrid(dttext); 
     };
function calNext(){    
     scheduler.setCurrentView(scheduler.date.add(scheduler.date[scheduler._mode + "_start"](scheduler._date),  1,"unit"));
     parent.changeScheduleHeader();
     var calDate = document.getElementsByClassName("dhx_cal_date");
     dttext = calDate[0].innerHTML;
     loadTreeGrid(dttext); 
}
function calToday(){
     scheduler.callEvent("onBeforeTodayDisplayed", []) && scheduler.setCurrentView(scheduler._currentDate());
     parent.changeScheduleHeader();
     var calDate = document.getElementsByClassName("dhx_cal_date");
     dttext = calDate[0].innerHTML;
     loadTreeGrid(dttext); 
}

function loadTreeGrid(loadDate){    
          schedulerLayout.cells("a").progressOn();
          var selEmp = parent.myEmployeeCombo.getSelectedValue(); 
          gridTree.clearAndLoad('Controller/openTasks.php?date='+loadDate+"&branch="+branch+"&selEmp="+selEmp+"&uid="+emp,function(){
             schedulerLayout.cells("a").progressOff();
             gridTree.expandAll();

          });    
} 
function postPhoneEvent(schedulerEventId){           
            
        var today = new Date(); 
        var starteDate = formattedDate(today); 
        var starteTime = formattedTime(today);
        var tomorrow = new Date();
        var tomorrow = tomorrow.addDays(1);   
        var endDate = formattedDate(tomorrow); 
        var endTime = formattedTime(tomorrow);   
       
                      var   changePFormData = [                
                         {type: "settings", position: "label-top",offsetLeft :25,offsetTop :0},                             
                           {type: "label", offsetLeft :0, list:[
                              {type: "input",style:"margins-left:-20px;", offsetLeft :0, position: "label-left",label: "Postphone to:", value: endDate,  name:"pdate",className : "formbox", inputWidth: "100"}
                           ]},
                         {type: "label", offsetLeft :0, list:[
                              {type: "input",style:"margins-left:-20px;",value: starteTime, offsetLeft :0, label: "Begin",  name:"begin",className : "formbox", inputWidth: "65"},
                              {type: "newcolumn"},
                              {type: "input",style:"margins-left:-20px;",value: endTime, offsetLeft :1, label: "End", name:"end",className : "formbox", inputWidth: "65"}
                          ]}, 								
                          {type: "label", offsetLeft :0, list:[
                              {type: "button", label: "Ok", position: "label-left", name: "ok", value: "OK", inputWidth: 100, offsetLeft :5},
                              {type: "newcolumn"},
                              {type: "button", label: "Cancel", position: "label-left", name: "cancel", value: "Cancel", inputWidth: 100, offsetLeft :5}  
                          ]} 
                         ]; 
            
                       var dhxWinsPostPone = new dhtmlXWindows();                                  
                       var wD = screen.width/2.5;
                       // var hD = screen.heigth/2;
                       _postPWindow = dhxWinsPostPone.createWindow("w1",wD,200, 260, 235);                                    
                       _postPWindow.setText("Select Task Date");
                       _postPWindow.button("park").disable();
                       _postPWindow.denyResize();
                       _postPWindow.denyMove();
                       _postPWindow.setModal(true);
                       var rescheduleForm = _postPWindow.attachForm(changePFormData);
                       _postPWindow.attachEvent("onClose", function(w){
                               _postPWindow.detachObject();
                               _postPWindow.hide();
                               _postPWindow.setModal(false);
                       });
                      
                       $(".dhxwin_active").css("z-index", "10000000"); 
                       
                        rescheduleForm.attachEvent("onButtonClick", function(id)        
                          {
                               switch(id)
                                   {
                                    case 'ok':   	
                                     rescheduleForm.send("Controller/data.php?action=2&event_id="+schedulerEventId,function(loader, response){                                
                                      
                                      var scheduleObj = JSON.parse(response);
                                      if(scheduleObj.bool){
                                            refresh();
                                            scheduler.callEvent("onEventCancel", [scheduler._lightbox_id, scheduler._new_event]), scheduler.endLightbox(!1), scheduler.hide_lightbox();
                                           _postPWindow.detachObject();
                                           _postPWindow.hide();
                                           _postPWindow.setModal(false);
                                        dhtmlx.message(scheduleObj.response);  
                                      }else{
                                        dhtmlx.alert(scheduleObj.response);  
                                      }
                                      
                                     });
                                    break;                    
                                    case 'cancel':                    
                                           _postPWindow.detachObject();
                                           _postPWindow.hide();
                                           _postPWindow.setModal(false);
                                    break;
                                   }
                        }); 
                       
  }
 function padZ(num, n) {
        n = n || 1; // Default assume 10^1
        return num < Math.pow(10, n) ? "0" + num : num;
    }

 function formattedDate(d) {
        var day = d.getDate();
        var month = d.getMonth() + 1; // Note the `+ 1` -- months start at zero.
        var year = d.getFullYear();
        var hour = d.getHours();
        var min = d.getMinutes();
        var sec = d.getSeconds();
        return year+"-"+month+"-"+day ;
    }
 function formattedTime(d) {
        var day = d.getDate();
        var month = d.getMonth() + 1; // Note the `+ 1` -- months start at zero.
        var year = d.getFullYear();
        var hour = d.getHours();
        var min = d.getMinutes();
        var sec = d.getSeconds();
        return hour+":"+padZ(min)+":"+padZ(sec);
    }
    Date.prototype.addDays = function(days) {
        this.setDate(this.getDate() + days);
        return this;
    };
    
       
function  refresh()
    {   
         scheduler.clearAll();                 
         scheduler.load("Controller/data.php?id="+branch,function(){
         });
    }