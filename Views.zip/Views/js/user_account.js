var myWidth;
var myHeight;

if (typeof (window.innerWidth) == 'number') {

    //Non-IE 

    myWidth = window.innerWidth;
    myHeight = window.innerHeight;

} else if (document.documentElement && (document.documentElement.clientWidth || document.documentElement.clientHeight)) {

    //IE 6+ in 'standards compliant mode' 

    myWidth = document.documentElement.clientWidth;
    myHeight = document.documentElement.clientHeight;

} else if (document.body && (document.body.clientWidth || document.body.clientHeight)) {

    //IE 4 compatible 

    myWidth = document.body.clientWidth;
    myHeight = document.body.clientHeight;

}

usersgridGrid = new dhtmlXGridObject('usersgrid');
usersgridGrid.setHeader('User Id,Reg Number,Password,User Type');
usersgridGrid.setImagePath("http://" + location.host + "/Controller/include/dhtmlx6/skins/web/imgs/");
usersgridGrid.setColumnIds('user_id,lect_id,password,previlages');
usersgridGrid.setSkin('dhx_web');
usersgridGrid.setInitWidthsP('25,25,25,25');
usersgridGrid.setColAlign("left,left,left,left");
usersgridGrid.enableDragAndDrop(false);
usersgridGrid.enableMercyDrag(false);
usersgridGrid.setColTypes('ed,combo,ed,combo'); //dhxCalendar
usersgridGrid.setDateFormat("%Y-%m-%d %H:%i:%s");
usersgridGrid.setColSorting("int,str,str,str,str");
usersgridGrid.enableSmartRendering("true");
usersgridGrid.enableMultiselect(true);
usersgridGrid.init();
usersgridGrid.clearAndLoad("../data_controller.php?action=35");



usersgridGrid.attachEvent("onSelectStateChanged", function(id){  
   usersform.clear();
   usersform.load("../data_controller.php?action=36&user_id=" + id, function() {});
  
 });
 
usersgridGrid.attachEvent("onXLE", function(id) {
var previlages_combo =usersgridGrid.getColumnCombo(3);
previlages_combo.clearAll();
previlages_combo.load("../data_controller.php?action=45&item_value=9");

});



//user edit grid
usersgridGrid.attachEvent("onEditCell", function(stage, rId, cInd, nValue, oValue) {
    var field =usersgridGrid.getColumnId(cInd);  
    if (stage == 2)
    {
        $.post("../data_controller.php?action=34", "&field=" + field + "&fieldvalue=" + nValue + "&login_id=" + rId, function(data) {
            if (data.data.success)
            {
            usersgridGrid.cells(rId, cInd).setValue(nValue);
            }
        }, 'json');
    }
});

 // attach form
var userformStructure=[
    {type: "settings", position: "label-left", labelWidth: window.innerWidth /15, inputWidth: window.innerWidth /8},
  //  {type: "container", name: "pic", label: "", inputWidth: 160, inputHeight: 160, offsetTop: 10, offsetLeft: 65},
   // {type: "upload", name: "myFiles", label: "Upload Photo",inputWidth: 320,offsetLeft: 10, url: "php/dhtmlxform_item_upload.php", swfPath: "uploader.swf", swfUrl: "php/dhtmlxform_item_upload.php"},
    {type: "input", name: "userid", label: "User Id",offsetLeft: window.innerWidth /90},
    {type: "combo", name: "username", label: "Username",offsetLeft: window.innerWidth /90},
    {type: "input", name: "password", label: "password",offsetLeft: window.innerWidth /90},
    {type: "combo", name: "category", label: "User Type",offsetLeft: window.innerWidth /90},
    {type: "checkbox", name: "active", label: "Active",offsetLeft: window.innerWidth /90}
];

var usersform = new dhtmlXForm("usersform", userformStructure);

var usercombo = usersform.getCombo("username");
usercombo.enableAutocomplete();
usercombo.enableFilteringMode(true);
usercombo.clearAll();
usercombo.load("../data_controller.php?action=31")

var previlagecombo = usersform.getCombo("category");
previlagecombo.enableAutocomplete();
previlagecombo.enableFilteringMode(true);
previlagecombo.clearAll();
previlagecombo.load("../data_controller.php?action=44&item_value=9");


usersToolbar =new dhtmlXToolbarObject("user_toolbar");
usersToolbar.addButton("new", 1, "<i class='fa fa-plus '></i>&nbsp;&nbsp;New");
usersToolbar.addSeparator("sep2", 2);
usersToolbar.addButton("delete", 3, "<i class='fa fa-trash '></i>&nbsp;&nbsp;Delete");
usersToolbar.addSeparator("sep2",4);
usersToolbar.addButton("save", 5, "<i class='fa fa-floppy-o '></i> &nbsp;&nbsp; Save");

usersToolbar.attachEvent("onClick", function(id)
{
    var user_id =usersgridGrid.getSelectedRowId();
      if (id == "new")
    {
        $.post("../data_controller.php?action=32", function(data) {
            if (data.response)
            {
                dhtmlx.message({
                    text: "New record has been created!",
                    expire: 1000
                });
                usersgridGrid.clearAndLoad("../data_controller.php?action=35");
              }
        }, 'json');
    }

    else if (id == "delete")
    {
        dhtmlx.confirm({
            title: "Confirm",
            type: "confirm-warning",
            text: "Are you sure you  want to delete this record?",
            callback: function(y) {
                if (y)
                {
                    
                    $.get("../data_controller.php?action=33&id=" + user_id, function(data) {
                        usersgridGrid.deleteRow(user_id);
                        dhtmlx.message(data.message);
                    }, 'json');
                }
                else
                {
                    return false;
                }
            }});
    }
            else if(id=="save")
       {     
            usersform.send("../data_controller.php?action=37&user_id=" + user_id,
                function(loader, response)
                {
                    var data = eval('(' + response + ')');
                    if (data.success)
                    {
                        dhtmlx.message({
                            text: "Data  saved successfully !",
                            expire: 10000
                        });
                        usersgridGrid.cells(usersgridGrid.getSelectedRowId(), 1).setValue(data.username);
                        usersgridGrid.cells(usersgridGrid.getSelectedRowId(), 2).setValue(data.password);
                        }
                }, 'json');
       }
   });