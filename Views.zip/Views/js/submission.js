var myWidth;
var myHeight;

if (typeof (window.innerWidth) == 'number') {

    //Non-IE 

    myWidth = window.innerWidth;
    myHeight = window.innerHeight;

} else if (document.documentElement && (document.documentElement.clientWidth || document.documentElement.clientHeight)) {

    //IE 6+ in 'standards compliant mode' 

    myWidth = document.documentElement.clientWidth;
    myHeight = document.documentElement.clientHeight;

} else if (document.body && (document.body.clientWidth || document.body.clientHeight)) {

    //IE 4 compatible 

    myWidth = document.body.clientWidth;
    myHeight = document.body.clientHeight;

}

var transaction_layout = new dhtmlXLayoutObject("transaction_layout", "1C", "dhx_terrace");
transaction_tabber = transaction_layout.cells("a").attachTabbar();
transaction_tabber.setSkin('dhx_terrace');
transaction_tabber.addTab("income", "Income",myWidth*0.4);
transaction_tabber.addTab("expense", "Expences", myWidth*0.4);
transaction_tabber.tabs("income").setActive();
transaction_tabber.setArrowsMode('auto');


//incomes
var income_layout =transaction_tabber.cells('income').attachLayout("2E");
income_layout.cells("a").hideHeader();
income_layout.cells("b").hideHeader()

//expenditures
var expenditure_layout =transaction_tabber.cells('expense').attachLayout("2E");
expenditure_layout.cells("a").hideHeader();
expenditure_layout.cells("b").hideHeader()


//expenditures grid 
expenditure_grid =income_layout.cells('a').attachGrid();
expenditure_grid.setImagePath("http://" + location.host + "/Controller/include/dhtmlx6/skins/web/imgs/");
expenditure_grid.setHeader('#,Contribution Name,Amount,Date');
expenditure_grid.setColumnIds('cmr_id,complete,year,faculty');
expenditure_grid.setSkin('dhx_web');
expenditure_grid.setInitWidthsP('20,20,20,*');
expenditure_grid.setColAlign("left,left,left,left");
expenditure_grid.enableDragAndDrop(false);
expenditure_grid.enableMercyDrag(false);
expenditure_grid.setColTypes('ed,ed,ed,ed'); //dhxCalendar
expenditure_grid.setDateFormat("%Y-%m-%d %H:%i:%s");
expenditure_grid.setColSorting("str,str,str,str");
expenditure_grid.enableSmartRendering("true");
expenditure_grid.enableMultiselect(true);
//expenditure_grid.enablePaging(true, 5, null, "pagingArea", true, "recinfoArea")
expenditure_grid.init();
expenditure_grid.attachFooter("Totals,,,,,,,","font-style:normal;font-weight:bold;text-align:right;background-color:transparent;");  
//expenditure_grid.setPagingSkin("bricks");
expenditure_grid.clearAndLoad("../data_controller.php?action=46");




income_toolbar =income_layout.cells('a').attachToolbar();
income_toolbar.addButton("new", 2, "<i class='fa fa-plus '></i>&nbsp;&nbsp;New");
income_toolbar.addSeparator("sep2", 3);
income_toolbar.addButton("delete", 4, "<i class='fa fa-trash '></i>&nbsp;&nbsp;Delete");

 // attach form
var incomeformstruct=[
    {type: "settings", position: "label-left", labelWidth: 100, inputWidth: 150,offsetLeft: 20},    
    {type: "input", name: "name", label: "Name"},
    {type: "input", name: "phone", label: "Amount"},
    {type: "input", name: "email", label: "Category"},
];
var incomeForm =income_layout.cells('b').attachForm(incomeformstruct);



income_toolbar =income_layout.cells('b').attachToolbar();
income_toolbar.addButton("save", 1, "<i class='fa fa-floppy-o '></i> &nbsp;&nbsp; Save");

//expenditure 
income_grid =expenditure_layout.cells("a").attachGrid();
income_grid.setImagePath("http://" + location.host + "/Controller/include/dhtmlx6/skins/web/imgs/");
income_grid.setHeader('#,Expenditure Name,Amount,Date');
income_grid.setColumnIds('cmr_id,complete,year,faculty');
income_grid.setSkin('dhx_web');
income_grid.setInitWidthsP('20,20,20,*');
income_grid.setColAlign("left,left,left,left");
income_grid.enableDragAndDrop(false);
income_grid.enableMercyDrag(false);
income_grid.setColTypes('ed,ed,ed,ed'); //dhxCalendar
income_grid.setDateFormat("%Y-%m-%d %H:%i:%s");
income_grid.setColSorting("str,str,str,str");
income_grid.enableSmartRendering("true");
income_grid.enableMultiselect(true);
//income_grid.enablePaging(true, 5, null, "pagingArea", true, "recinfoArea")
income_grid.init();
income_grid.attachFooter("Totals,,,,,,,","font-style:normal;font-weight:bold;text-align:right;background-color:transparent;"); 
//income_grid.setPagingSkin("bricks");
income_grid.clearAndLoad("../data_controller.php?action=46");




expenditure_toolbar =expenditure_layout.cells("a").attachToolbar();
expenditure_toolbar.addButton("new", 2, "<i class='fa fa-plus '></i>&nbsp;&nbsp;New");
expenditure_toolbar.addSeparator("sep2", 3);
expenditure_toolbar.addButton("delete", 4, "<i class='fa fa-trash '></i>&nbsp;&nbsp;Delete");

 // attach form
var incomeformstruct=[
    {type: "settings", position: "label-left", labelWidth: 100, inputWidth: 150,offsetLeft: 20},    
    {type: "input", name: "Expense name", label: "Name"},
    {type: "input", name: "phone", label: "Amount"},
    {type: "input", name: "email", label: "Category"},
];
var incomeForm =expenditure_layout.cells("b").attachForm(incomeformstruct);



expenditure_toolbar =expenditure_layout.cells("b").attachToolbar();
expenditure_toolbar.addButton("save", 1, "<i class='fa fa-floppy-o '></i> &nbsp;&nbsp; Save");