<?php
session_start();
if (!isset($_SESSION["user_id"])) {
   header('location:../auth.php');
}
switch (($_SESSION['prevelages'])) {
    case 10:
     $_SESSION['access']=4;
      break;
    case 11:
       $_SESSION['access']=2; 
      break;  
    case 12:
        $_SESSION['access']=1; 
      break;
  default :
        header('location:../auth.php');
      break;
}
?>
<html>
    <head>
        <title>submission</title>
        <link rel="stylesheet" type="text/css" href="../include/dhtmlx6/skins/web/dhtmlx.css"/> 
        <link rel="stylesheet" type="text/css" href="../include/dhtmlx6/skins/terrace/dhtmlx.css"/> 
        <link href="assets/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="../../Views/css/fontawesome/css/font-awesome.min.css"/> 
        <script src="../../Views/jquery/jquery-2.2.1.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="../include/dhtmlx6/codebase/dhtmlx.js"></script>
        <script src="../include/tinymce/js/tinymce/tinymce.min.js"></script>

        <style>
            #layout{
                width:100%;
                height:100%;  
                padding: 0px;
                margin:0px;
            }
            .dhxlayout_base_dhx_terrace div.dhx_cell_layout div.dhx_cell_cont_layout {
                border-color: white !important;
                border-style: none !important;
                border-width: 0 0px 0px !important;
                overflow: hidden;
                position: absolute;
                z-index: 0;
            }
            div#editorObj {
                width: 100%;
                height: 300px;
                border: 1px solid #a4bed4;
            }
             .objbox
            {
            overflow: hidden !important;
            }
        </style>
    </head>
    <body >
        <div class="container">
                  <form> <input type="hidden" id="accessrights" value="<?php echo $_SESSION['access'];?>"/></form>
            <div class="row">
                <div id='submission_toolbar' class="col-sm-12" style="text-align:center;"></div> 
            </div>
            <div class="row">
                <div  class="col-sm-12" >
                    <div id="submissiongid" style="height:40%;width:100%;" ></div>
                </div>  


            </div>
            <div class="row">
                <div id='submission_savetoolbar' class="col-sm-12" style="text-align:center;"></div> 
            </div>
            <div class="row">
                <div  class="col-md-12">
                       <textarea  style="height:30%;width:100%;" id="submitdocument">..take notes.</textarea>
                </div>
              
            </div>

        </div>
        <script src="../../Views/js/submission.js"></script>
    </body>
</html>
