/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


var myWidth;
var myHeight;

if (typeof (window.innerWidth) == 'number') {

    //Non-IE 

    myWidth = window.innerWidth;
    myHeight = window.innerHeight;

} else if (document.documentElement && (document.documentElement.clientWidth || document.documentElement.clientHeight)) {

    //IE 6+ in 'standards compliant mode' 

    myWidth = document.documentElement.clientWidth;
    myHeight = document.documentElement.clientHeight;

} else if (document.body && (document.body.clientWidth || document.body.clientHeight)) {

    //IE 4 compatible 

    myWidth = document.body.clientWidth;
    myHeight = document.body.clientHeight;

}
var main_layout = new dhtmlXLayoutObject("main_layout", "1C", "dhx_terrace");
main_tabber = main_layout.cells("a").attachTabbar();
main_tabber.setSkin('dhx_terrace');
main_tabber.addTab("details", "Member Details");
main_tabber.addTab("visitors", "Visitors");
main_tabber.addTab("dedicated", "Dedicated");
main_tabber.addTab("baptised", "Baptised");
main_tabber.tabs("details").setActive();
main_tabber.setArrowsMode('auto');


//vistors layout
var vistors_Layout = main_tabber.cells("visitors").attachLayout("2E");
vistors_Layout.cells("a").hideHeader();
vistors_Layout.cells("b").hideHeader();
vistors_Layout.cells("a").setHeight(myHeight * 0.34)

//dedicated layout

var dedicated_Layout = main_tabber.cells("dedicated").attachLayout("2E");
dedicated_Layout.cells("a").hideHeader();
dedicated_Layout.cells("b").hideHeader();
dedicated_Layout.cells("a").setHeight(myHeight * 0.5)

//baptised layout
var baptised_Layout = main_tabber.cells("baptised").attachLayout("2E");
baptised_Layout.cells("a").hideHeader();
baptised_Layout.cells("b").hideHeader();
baptised_Layout.cells("a").setHeight(myHeight * 0.5)

var memberdetails_Layout = main_tabber.cells("details").attachLayout("2E");
memberdetails_Layout.cells("a").hideHeader();
memberdetails_Layout.cells("b").hideHeader();
memberdetails_Layout.cells("a").setHeight(myHeight * 0.36)



//lower tabers
memberdetails_taber = memberdetails_Layout.cells("b").attachTabbar();
memberdetails_taber.setSkin('dhx_terrace');
memberdetails_taber.addTab("memberdetails", "Member Details");
memberdetails_taber.addTab("contribution", "Contribution");
//memberdetails_taber.addTab("group", "Group");
memberdetails_taber.tabs("memberdetails").setActive();
memberdetails_taber.setArrowsMode('auto');

//members grid
members_details_grid = memberdetails_Layout.cells("a").attachGrid();
members_details_grid.setHeader('Reg No,Name,Phone,Email,Gender,Home Cell,Marital Status,Category');
members_details_grid.setImagePath("http://" + location.host + "/Controller/include/dhtmlx6/skins/web/imgs/");
members_details_grid.setColumnIds('regno,name,phone,email,gender,home_cell,marital,category');
members_details_grid.attachHeader("#text_filter,#text_filter,#numeric_filter,#text_filter,#text_filter,#text_filter,#text_filter,#text_filter");
members_details_grid.setSkin('dhx_web');
members_details_grid.setInitWidthsP('10,*,10,15,10,10,10,0');
members_details_grid.setColAlign("left,left,left,left,left,left,left,left");
members_details_grid.enableDragAndDrop(false);
members_details_grid.enableMercyDrag(false);
members_details_grid.setColTypes('ro,ed,ro,ro,ro,ro,ro,ro');
members_details_grid.setDateFormat("%Y-%m-%d %H:%i:%s");
members_details_grid.setColSorting("int,str,str,str,str,str,str,str");
members_details_grid.enableSmartRendering("true");
members_details_grid.enableMultiselect(true);
members_details_grid.init();

var currentTime = new Date()
var month = currentTime.getMonth() + 1;
var year = currentTime.getFullYear()
members_details_grid.clearAndLoad("../data_controller.php?action=5&month=" + month + "&year=" + year);
members_details_grid.attachEvent("onXLE", doeditor_gridselectionXLE);

function doeditor_gridselectionXLE(grid, count) {
    var i = members_details_grid.getSelectedRowId();
    if ((i == -1) || (i == null)) {
        i = 0;
    }
    members_details_grid.setSelectedRow(i);
    members_details_grid.selectRow(i);
}

//
members_details_grid.attachEvent("onEditCell", function (stage, rId, cInd, nValue, oValue) {
    var field = members_details_grid.getColumnId(cInd);

    if (stage == 2)
    {
        $.post("../data_controller.php?action=4", "&field=" + field + "&fieldvalue=" + nValue + "&reg_no=" + rId, function (data) {
            if (data.data.success)
            {
                members_details_grid.cells(rId, cInd).setValue(nValue);
            }
        }, 'json');
    } else if (field == "active")
    {
        if (typeof nValue == "undefined")
        {
            var cell = members_details_grid.cells(rId, cInd);
            var cValue = cell.getValue();

            if (cValue == 1)
            {
                cell.setValue(0);
                $.post("../data_controller.php?action=28", "&field=" + field + "&fieldvalue=" + 0 + "&lect_id=" + rId, function (data) {
                    if (data.success)
                    {

                    }
                });

            } else if (cValue == 0)
            {
                members_details_grid.selectRowById(rId);
                cell.setValue(1);
                $.post("../data_controller.php?action=28", "&field=" + field + "&fieldvalue=" + 1 + "&lect_id=" + rId, function (data) {
                    if (data.success)
                    {

                    }
                });
            }
        }
    } else if (stage == 1)
    {


    }
});

var gender_combo = members_details_grid.getColumnCombo(4);
var home_cell_combo = members_details_grid.getColumnCombo(5);
var marital_status = members_details_grid.getColumnCombo(6);
var category_combo = members_details_grid.getColumnCombo(7);
members_details_grid.attachEvent("onXLE", function (id) {
    gender_combo.clearAll();
    gender_combo.load("../data_controller.php?action=42&item_value=1");

    marital_status.clearAll();
    marital_status.load("../data_controller.php?action=42&item_value=13");

    home_cell_combo.clearAll();
    home_cell_combo.load("../data_controller.php?action=43");

    category_combo.clearAll();
    category_combo.load("../data_controller.php?action=42&item_value=17");

});


members_details_grid.attachEvent("onSelectStateChanged", function (id) {

    reg_no = id;
    membersForm.clear();
    membersForm.load("../data_controller.php?action=7&reg_no=" + id, function () {

    });
    members_contribution_grid.clearAndLoad("../data_controller.php?action=11&reg_no=" + id);
    setFooterSum(id);

});

// members detail form
var formStructure = [
    // {type: "fieldset", name: "mydata", label: "Member Details", width: myWidth * 0.94, offsetLeft: 10, className:"fs_info",list: [
    {type: "settings", position: "label-left", labelWidth: 140, inputWidth: 180, offsetLeft: 15},
    {type: "input", name: "name", label: "Name"},
    {type: "input", name: "phone", label: "Phone"},
    {type: "input", name: "email", label: "E-mail"},
    {type: "input", name: "address", label: "Address"},
    {type: "combo", name: "gender", label: "Gender", options: [
            {text: "Male", value: "2"},
            {text: "Female", value: "3"}
        ]},
    {type: "combo", name: "marital", label: "Marital Status", options: [
            {text: "Single", value: "14"},
            {text: "Married", value: "15"},
            {text: "Engaged", value: "16"}
        ]},
    {type: "newcolumn"},
    {type: "calendar", name: "d_saved", label: "Date Saved", dateFormat: "%Y-%m-%d"},
    {type: "hidden", name: "p_church", label: "Previous Church Name"},
    {type: "combo", name: "homecell", label: "Home Cell", options: [
            {text: "Reharboth", value: "Reharboth"},
            {text: "Patmos", value: "Patmos"},
            {text: "Elishadai", value: "Elishadai"},
            {text: "Ebenezar", value: "Ebenezar"},
            {text: "Bethsaida", value: "Bethsaida"},
            {text: "Emanuel", value: "Emanuel"},
        ]},
    {type: "checkbox", name: "agree_t", label: "Agree with Teachings"},
    {type: "checkbox", name: "agree_s", label: "Agree Church Support"},
    {type: "checkbox", name: "active", label: "Active Member"},
    {type: "newcolumn"},
    {type: "image", name: "upload", label: "Photo", position: "label-top", imageWidth: 150, imageHeight: 150, url: "../imagesupload.php"},
    // ]},
];

var membersForm = memberdetails_taber.cells("memberdetails").attachForm(formStructure);

//
membersForm.attachEvent("onUploadFail", function (count) {
    dhtmlx.message({
        text: "upload failed!",
        expire: 1000
    });
});


//membersTopToolbar
membersTopToolbar = memberdetails_Layout.cells("a").attachToolbar();
membersTopToolbar.addButton("new", 1, "<i class='fa fa-plus '></i>&nbsp;&nbsp;New Member");
membersTopToolbar.addButton("refresh", 2, "<i class='fa fa-refresh fa-spin '></i>&nbsp;&nbsp;Refresh");
membersTopToolbar.addButton("delete", 3, "<i class='fa fa-trash '></i>&nbsp;&nbsp;Delete member");
membersTopToolbar.addButton("excell", 4, "<i class='fa fa-file-excel-o '></i>&nbsp;&nbsp;Excell");
var month_opts = [
    ['Today', 'obj', 'Today'],
    ['sep01', 'sep', '', ''],
    ['01', 'obj', 'Jan'],
    ['sep01', 'sep', '', ''],
    ['02', 'obj', 'Feb'],
    ['sep01', 'sep', '', ''],
    ['03', 'obj', 'Mar'],
    ['sep01', 'sep', '', ''],
    ['04', 'obj', 'Apr', ],
    ['sep01', 'sep', '', ''],
    ['05', 'obj', 'May', ],
    ['sep01', 'sep', '', ''],
    ['06', 'obj', 'June', ],
    ['sep01', 'sep', '', ''],
    ['07', 'obj', 'Jul', ],
    ['sep01', 'sep', '', ''],
    ['08', 'obj', 'Aug', ],
    ['sep01', 'sep', '', ''],
    ['09', 'obj', 'Sep', ],
    ['sep01', 'sep', '', ''],
    ['10', 'obj', 'Oct', ],
    ['sep01', 'sep', '', ''],
    ['11', 'obj', 'Nov', ],
    ['sep01', 'sep', '', ''],
    ['12', 'obj', 'Dec', ],
    ['All', 'obj', 'All']
];
membersTopToolbar.addButtonSelect("months", 5, "Choose Month", month_opts);

var year_opts = [
    ['2016', 'obj', '2016', ],
    ['sep01', 'sep', '', ''],
    ['2017', 'obj', '2017', ],
    ['sep01', 'sep', '', ''],
    ['2018', 'obj', '2018', ],
    ['sep01', 'sep', '', ''],
    ['2019', 'obj', '2019', ],
    ['sep01', 'sep', '', ''],
    ['2020', 'obj', '2020', ],
    ['sep01', 'sep', '', ''],
    ['2020', 'obj', '2021', ],
    ['sep01', 'sep', '', ''],
    ['2020', 'obj', '2022', ]
];

membersTopToolbar.addButtonSelect("years", 6, "Choose Year", year_opts);

membersTopToolbar.attachEvent("onClick", function (id)
{
    var lect_id = members_details_grid.getSelectedRowId();
    if (id == "new")
    {
        $.post("../data_controller.php?action=2", function (data) {
            if (data.response)
            {
                dhtmlx.message({
                    text: "New record has been created!",
                    expire: 1000
                });
                members_details_grid.clearAndLoad("../data_controller.php?action=5");
            }
        }, 'json');
    } else if (id == "delete")
    {
        dhtmlx.confirm({
            title: "Confirm",
            type: "confirm-warning",
            text: "Are you sure you  want to delete this record?",
            callback: function (y) {
                if (y)
                {

                    $.get("../data_controller.php?action=3&id=" + lect_id, function (data) {
                        members_details_grid.deleteRow(lect_id);
                        dhtmlx.message(data.message);
                    }, 'json');
                } else
                {
                    return false;
                }
            }});
    } else if (id == "excell")
    {
        window.open("http://" + location.host + "/financials/Controller/excellfiles/members.php")
    } else if (id == "refresh")
    {
        members_details_grid.clearAndLoad("../data_controller.php?action=5");
    } else if (membersTopToolbar.getParentId(id) == "months")
    {
        membersTopToolbar.setItemText("months", id);
        members_details_grid.clearAndLoad("../data_controller.php?action=5&month=" + id);
    } else if (membersTopToolbar.getParentId(id) == "years")
    {
        membersTopToolbar.setItemText("years", id);
        members_details_grid.clearAndLoad("../data_controller.php?action=5&year=" + id);


    } else if (id == "upload")
    {
        uploadimgs();
    }


});

//memberslowerToolbar
memberslowerToolbar = memberdetails_taber.cells("memberdetails").attachToolbar();
memberslowerToolbar.addButton("save", 1, "<i class='fa fa-floppy-o '></i> &nbsp;&nbsp; Save");
memberslowerToolbar.attachEvent("onClick", function (id)
{
    var reg_no = members_details_grid.getSelectedRowId();
    if (id == "save")
    {

        membersForm.send("../data_controller.php?action=6&reg_no=" + reg_no,
                function (loader, response)
                {
                    var data = eval('(' + response + ')');
                    if (data.success)
                    {
                        dhtmlx.message({
                            text: "Data  saved successfully !",
                            expire: 10000
                        });
                        members_details_grid.cells(members_details_grid.getSelectedRowId(), 1).setValue(data.name);
                        members_details_grid.cells(members_details_grid.getSelectedRowId(), 2).setValue(data.phone);
                        members_details_grid.cells(members_details_grid.getSelectedRowId(), 3).setValue(data.email);
                        members_details_grid.cells(members_details_grid.getSelectedRowId(), 4).setValue(data.gender);
                        members_details_grid.cells(members_details_grid.getSelectedRowId(), 5).setValue(data.homecell);
                        members_details_grid.cells(members_details_grid.getSelectedRowId(), 6).setValue(data.marital);
                        members_details_grid.cells(members_details_grid.getSelectedRowId(), 7).setValue(data.category);
                    }
                }, 'json');
    }


});

//members contribution Layout
var member_contribution_Layout = memberdetails_taber.cells("contribution").attachLayout("2U")
member_contribution_Layout.cells("a").hideHeader();
member_contribution_Layout.cells("b").hideHeader();
member_contribution_Layout.cells("a").setWidth(myWidth * 0.5)

//members contribution grid
members_contribution_grid = member_contribution_Layout.cells("a").attachGrid();
members_contribution_grid.setHeader("Date,Tithe,First Fruit,Love Offering,Evangelism,Faith Seed,Prophetic Seed,Thanks Giving,Pastor's Blessing,Welfare,Total");
members_contribution_grid.setImagePath("http://" + location.host + "/Controller/include/dhtmlx6/skins/web/imgs/");
members_contribution_grid.setColumnIds('date,tithe,first_fruit,love_offering,evangelism,blessings,others,thanksgiving,paster_blessing,welfare,total');
members_contribution_grid.attachHeader(",#numeric_filter,#text_filter,#numeric_filter,#text_filter,#text_filter,#text_filter,#text_filter,#text_filter,#text_filter,#text_filter");
members_contribution_grid.setSkin('dhx_web');
members_contribution_grid.setInitWidthsP('*,10,10,10,10,10,10,10,10,10,10');
members_contribution_grid.setColAlign("left,left,left,left,left,left,left,left,left,left,left");
members_contribution_grid.enableDragAndDrop(false);
members_contribution_grid.enableMercyDrag(false);
members_details_grid.setColTypes('ro,ed,ed,ed,ed,ed,ed,ed,ed,ed,ro');
members_contribution_grid.setDateFormat("%Y-%m-%d %H:%i:%s");
members_contribution_grid.setColSorting("int,int,int,int,int,int,int,int,int,int,int");
members_contribution_grid.enableSmartRendering("true");
members_contribution_grid.enableMultiselect(true);
members_contribution_grid.attachFooter("Totals,,,,,,,,,,", "font-style:normal;font-weight:bold;text-align:right;background-color:transparent;");
members_contribution_grid.init();
members_contribution_grid.attachEvent("onXLE", do_gridselectionXLE);

function do_gridselectionXLE(grid, count) {
    var i = members_contribution_grid.getSelectedRowId();
    if ((i == -1) || (i == null)) {
        i = 0;
    }
    members_contribution_grid.setSelectedRow(i);
    members_contribution_grid.selectRow(i);
}


//member contribution select
members_contribution_grid.attachEvent("onSelectStateChanged", function (id) {
    members_contribution_Form.clear();
    members_contribution_Form.load("../data_controller.php?action=13&id=" + id, function () {
    });
    // setsingleFooterSum(id);
});


members_contribution_grid.attachEvent("onEditCell", function (stage, rId, cInd, nValue, oValue) {
    var field = members_contribution_grid.getColumnId(cInd);
    var reg_no = members_details_grid.getSelectedRowId();
    if (stage == 2)
    {
        $.post("../data_controller.php?action=10", "&field=" + field + "&fieldvalue=" + nValue + "&id=" + rId, function (data) {
            if (data.data.success)
            {
                members_contribution_grid.cells(rId, cInd).setValue(nValue);
                setFooterSum(reg_no);
                members_contribution_grid.updateFromXML("../data_controller.php?action=11&reg_no=" + reg_no);
            }
        }, 'json');
    }

});
//contribution form structure
var contribution_formStructure = [
    //  {type: "fieldset", name: "mydata", label: "Member contribution", height: myHeight * 0.9, offsetLeft: 5, list: [
    {type: "settings", position: "label-left", labelWidth: 100, inputWidth: 110, offsetLeft: 10},
    {type: "input", name: "no", label: "Date", readonly: true},
    {type: "input", name: "tithe", label: "Tithe"},
    {type: "input", name: "first_fruit", label: "First Fruit"},
    {type: "input", name: "love", label: "Love Offering"},
    {type: "input", name: "evang", label: "Evangelism"},
    {type: "input", name: "seed", label: "Faith Seed"},
    {type: "newcolumn"},
    {type: "input", name: "others", label: "Prophetic Seed"},
    {type: "input", name: "thanks", label: "Thanksgiving Offering"},
    {type: "input", name: "blessings", label: "Pastor's Blessing"},
    {type: "input", name: "welfare", label: "Welfare"},
    {type: "input", name: "total", label: "Total Amount", readonly: true}
    //   ]},
];

var members_contribution_Form = member_contribution_Layout.cells("b").attachForm(contribution_formStructure);

members_contribution_Form.attachEvent("onFocus", function (name) {
    var first_fruit = members_contribution_Form.getItemValue('first_fruit');
    var love = members_contribution_Form.getItemValue('love');
    var tithe = members_contribution_Form.getItemValue('tithe');
    var evang = members_contribution_Form.getItemValue('evang');
    var seed = members_contribution_Form.getItemValue('seed');
    var others = members_contribution_Form.getItemValue('others');
    var thanks = members_contribution_Form.getItemValue('thanks');
    var blessings = members_contribution_Form.getItemValue('blessings');
    var welfare = members_contribution_Form.getItemValue('welfare');
    if (first_fruit == '0.00' && love == '0.00' && evang == '0.00' && seed == '0.00' && others == '0.00' && thanks == '0.00' && blessings == '0.00' && welfare == '0.00' && tithe == '0.00')
    {
        members_contribution_Form.setItemValue('men', '');
        members_contribution_Form.setItemValue('love', '');
        members_contribution_Form.setItemValue('tithe', '');
        members_contribution_Form.setItemValue('evang', '');
        members_contribution_Form.setItemValue('first_fruit', '');
        members_contribution_Form.setItemValue('seed', '');
        members_contribution_Form.setItemValue('others', '');
        members_contribution_Form.setItemValue('thanks', '');
        members_contribution_Form.setItemValue('blessings', '')
        members_contribution_Form.setItemValue('welfare', '');
    }
});
//members_contribution_Form.attachEvent("onBlur", function(name, value){
// var id = members_contribution_grid.getSelectedRowId();
//     $.get("../data_controller.php?action=14&id="+id, function(data) {
//            if(data.data.totals)
//          {
//            members_contribution_Form.setItemValue('total', data.data.totals);
//          }
//        }, 'json');
//});


//membersTopToolbar
members_contribution_Toolbar = member_contribution_Layout.cells("a").attachToolbar();
members_contribution_Toolbar.addButton("new", 1, "<i class='fa fa-plus '></i>&nbsp;&nbsp;Add");
members_contribution_Toolbar.addButton("delete", 2, "<i class='fa fa-trash '></i>&nbsp;&nbsp;Delete");
//var month_opts = [
//    ['Today', 'obj', 'Today'],
//    ['sep01', 'sep', '', ''],
//    ['01', 'obj', 'Jan'],
//    ['sep01', 'sep', '', ''],
//    ['02', 'obj', 'Feb'],
//    ['sep01', 'sep', '', ''],
//    ['03', 'obj', 'Mar'],
//    ['sep01', 'sep', '', ''],
//    ['04', 'obj', 'Apr', ],
//    ['sep01', 'sep', '', ''],
//    ['05', 'obj', 'May', ],
//    ['sep01', 'sep', '', ''],
//    ['06', 'obj', 'June', ],
//    ['sep01', 'sep', '', ''],
//    ['07', 'obj', 'Jul', ],
//    ['sep01', 'sep', '', ''],
//    ['08', 'obj', 'Aug', ],
//    ['sep01', 'sep', '', ''],
//    ['09', 'obj', 'Sep', ],
//    ['sep01', 'sep', '', ''],
//    ['10', 'obj', 'Oct', ],
//    ['sep01', 'sep', '', ''],
//    ['11', 'obj', 'Nov', ],
//    ['sep01', 'sep', '', ''],
//    ['12', 'obj', 'Dec', ],
//    ['All', 'obj', 'All']
//];
//members_contribution_Toolbar.addButtonSelect("month_report", 3, "Choose Month", month_opts);
//members_contribution_Toolbar.addButton("print", 4, "<i class='fa fa-print '></i>&nbsp;&nbsp;Print");
members_contribution_Toolbar.addButton("excell", 3, "<i class='fa fa-file-excel-o' aria-hidden='true'></i>&nbsp;&nbsp;Excell");

members_contribution_Toolbar.attachEvent("onClick", function (id)
{
    var reg_no = members_details_grid.getSelectedRowId();
    var select_id = members_contribution_grid.getSelectedRowId();
    if (id == "new")
    {
        $.post("../data_controller.php?action=8&reg_no=" + reg_no, function (data) {
            if (data.response)
            {
                dhtmlx.message({
                    text: "New record has been created!",
                    expire: 1000
                });
                members_contribution_grid.clearAndLoad("../data_controller.php?action=11&reg_no=" + reg_no);
            }
        }, 'json');
    } else if (id == "delete")
    {
        dhtmlx.confirm({
            title: "Confirm",
            type: "confirm-warning",
            text: "Are you sure you  want to delete this record?",
            callback: function (y) {
                if (y)
                {

                    $.get("../data_controller.php?action=9&id=" + select_id, function (data) {
                        members_contribution_grid.deleteRow(select_id);
                        dhtmlx.message(data.message);
                    }, 'json');
                } else
                {
                    return false;
                }
            }});
    } else if (id == "excell")
    {
        window.open("http://" + location.host + "/financials/Controller/excellfiles/members_contribution.php?reg_no=" + reg_no)
    } else if (id == "print")
    {
        window.open("http://" + location.host + "/financials/Controller/pdf.php?reg_no=" + reg_no + "&br=6&type=2", "Details", "height=900,width=710");
    } else if (members_contribution_Toolbar.getItemText("month_report"))
    {
        members_contribution_grid.clearAndLoad("../data_controller.php?action=30&month=" + id + "&regno=" + reg_no);

    }
});
// //members save Toolbar
members_save_Toolbar = member_contribution_Layout.cells("b").attachToolbar();
members_save_Toolbar.addButton("save", 1, "<i class='fa fa-floppy-o '></i> &nbsp;&nbsp; Save");

members_save_Toolbar.attachEvent("onClick", function (id)
{
    var reg_no = members_details_grid.getSelectedRowId();
    if (id == "save")
    {
        var id = members_contribution_grid.getSelectedRowId();
        members_contribution_Form.send("../data_controller.php?action=14&id=" + id,
                function (loader, response)
                {
                    var data = eval('(' + response + ')');
                    if (data.success)
                    {
                        dhtmlx.message({
                            text: "Data  saved successfully !",
                            expire: 10000
                        });
                        members_contribution_grid.cells(members_contribution_grid.getSelectedRowId(), 1).setValue(data.tithe);
                        members_contribution_grid.cells(members_contribution_grid.getSelectedRowId(), 2).setValue(data.first_fruit);
                        members_contribution_grid.cells(members_contribution_grid.getSelectedRowId(), 3).setValue(data.love);
                        members_contribution_grid.cells(members_contribution_grid.getSelectedRowId(), 4).setValue(data.evang);
                        members_contribution_grid.cells(members_contribution_grid.getSelectedRowId(), 5).setValue(data.seed);
                        members_contribution_grid.cells(members_contribution_grid.getSelectedRowId(), 6).setValue(data.others);
                        members_contribution_grid.cells(members_contribution_grid.getSelectedRowId(), 7).setValue(data.thanksgiving);
                        members_contribution_grid.cells(members_contribution_grid.getSelectedRowId(), 8).setValue(data.blessings)
                        members_contribution_grid.cells(members_contribution_grid.getSelectedRowId(), 9).setValue(data.welfare);
                        members_contribution_grid.cells(members_contribution_grid.getSelectedRowId(), 10).setValue(data.total);
                        setFooterSum(reg_no);
                        members_contribution_Form.clear();
                        members_contribution_Form.load("../data_controller.php?action=13&id=" + id, function () {
                        });
                    }
                }, 'json');
    }
});

////member's group
//var group_tree = memberdetails_taber.cells("group").attachTree();
//group_tree.setSkin('dhx_web');
//group_tree.setImagePath("http://" + location.host + "/financials/Controller/include/dhtmlx6/skins/web/imgs/dhxtree_web/");
//group_tree.enableSmartXMLParsing(true);
//group_tree.enableCheckBoxes(true);
//group_tree.enableDragAndDrop(true);
//group_tree.enableThreeStateCheckboxes(false);
//group_tree.enableMultiselection(1, 0);
//group_tree.deleteChildItems(0);// before  the tree loads the curent tree  is deleted
//group_tree.loadXML("http://" + location.host + "/financials/Controller/data_controller.php?action=1", function() {
//    group_tree.openAllItems(0);
//});
//
//group_tree.attachEvent("onCheck", function(id) {
//    var postVars = {
//        "group_id": id,
//        "reg_no": members_details_grid.getSelectedRowId(),
//    };
//    $.post("../data_controller.php?action=15&id=", postVars, function(data)
//    {
//        dhtmlx.alert(data.response);
//    }, 'json');
//});

function setFooterSum(id)
{
    $.get("../data_controller.php?action=12&reg_no=" + id, function (data) {
        if (data.data.success)
        {
            var first_fruit = data.data.first_fruit;
            var love_offering = data.data.love_offering;
            var evangelism = data.data.evangelism;
            var blessings = data.data.seed;
            var others = data.data.others;
            var thanksgiving = data.data.thanksgiving;
            var paster_blessing = data.data.blessing;
            var others = data.data.others;
            var welfare = data.data.welfare;
            var totals = data.data.totals;
            members_contribution_grid.setFooterLabel(1, '' + others);
            members_contribution_grid.setFooterLabel(2, '' + first_fruit);
            members_contribution_grid.setFooterLabel(3, '' + love_offering);
            members_contribution_grid.setFooterLabel(4, '' + evangelism);
            members_contribution_grid.setFooterLabel(5, '' + blessings);
            members_contribution_grid.setFooterLabel(6, '' + others);
            members_contribution_grid.setFooterLabel(7, '' + thanksgiving);
            members_contribution_grid.setFooterLabel(8, '' + paster_blessing);
            members_contribution_grid.setFooterLabel(9, '' + welfare);
            members_contribution_grid.setFooterLabel(10, '' + totals);
        }
    }, 'json');
}
//visitors
visitors_grid = vistors_Layout.cells("a").attachGrid();
visitors_grid.setHeader('No,Name,Phone,Email,Gender,Home Cell,Marital Status,Category');
visitors_grid.setImagePath("http://" + location.host + "/Controller/include/dhtmlx6/skins/web/imgs/");
visitors_grid.setColumnIds('regno,name,phone,email,gender,home_cell,marital,category');
visitors_grid.attachHeader("#text_filter,#text_filter,#numeric_filter,#text_filter,#text_filter,#text_filter,#text_filter,#text_filter");
visitors_grid.setSkin('dhx_web');
visitors_grid.setInitWidthsP('10,*,10,15,10,10,10,0');
visitors_grid.setColAlign("left,left,left,left,left,left,left,left");
visitors_grid.enableDragAndDrop(false);
visitors_grid.enableMercyDrag(false);
visitors_grid.setColTypes('ro,ed,ed,ed,ed,ed,ed,ed');
visitors_grid.setDateFormat("%Y-%m-%d %H:%i:%s");
visitors_grid.setColSorting("int,str,str,str,str,str,str,str");
visitors_grid.enableSmartRendering("true");
visitors_grid.enableMultiselect(true);
visitors_grid.init();
var currentTime = new Date()
var month = currentTime.getMonth()+ 1;
var year = currentTime.getFullYear()
visitors_grid.clearAndLoad("../data_visitors.php?action=4&month=" + month + "&year=" + year);
visitors_grid.attachEvent("onXLE", do_selectionXLE);


function do_selectionXLE(grid, count) {
    var i = visitors_grid.getSelectedRowId();
    if ((i == -1) || (i == null)) {
        i = 0;
    }
    visitors_grid.setSelectedRow(i);
    visitors_grid.selectRow(i);
}

visitors_grid.attachEvent("onEditCell", function (stage, rId, cInd, nValue, oValue) {
    var field = visitors_grid.getColumnId(cInd);

    if (stage == 2)
    {
        $.post("../data_visitors.php?action=3", "&field=" + field + "&fieldvalue=" + nValue + "&id=" + rId, function (data) {
            if (data.data.success)
            {
                visitors_grid.cells(rId, cInd).setValue(nValue);
            }
        }, 'json');
    }
});

//visitor selection grid
visitors_grid.attachEvent("onSelectStateChanged", function (id) {
    visitor_membersForm.clear();
    visitor_membersForm.load("../data_visitors.php?action=12&reg_no=" + id, function () {
    });
});



visitors_toolbar = vistors_Layout.cells("a").attachToolbar();
visitors_toolbar.addButton("add", 1, "<i class='fa fa-plus '></i>&nbsp;&nbsp;New");
visitors_toolbar.addButton("delete", 2, "<i class='fa fa-trash '></i>&nbsp;&nbsp;Delete");
visitors_toolbar.addButton("refresh", 3, "<i class='fa fa-refresh fa-spin '></i>&nbsp;&nbsp;Refresh");
visitors_toolbar.addButton("excell", 4, "<i class='fa fa-file-excel-o' aria-hidden='true'></i>&nbsp;&nbsp;Excell");
visitors_toolbar.addButton("export", 5, "<i class='fa fa-upload  faa-wrench animated'></i>&nbsp;&nbsp;Export to Members");
var month_opts = [
    ['Today', 'obj', 'Today'],
    ['sep01', 'sep', '', ''],
    ['01', 'obj', 'Jan'],
    ['sep01', 'sep', '', ''],
    ['02', 'obj', 'Feb'],
    ['sep01', 'sep', '', ''],
    ['03', 'obj', 'Mar'],
    ['sep01', 'sep', '', ''],
    ['04', 'obj', 'Apr', ],
    ['sep01', 'sep', '', ''],
    ['05', 'obj', 'May', ],
    ['sep01', 'sep', '', ''],
    ['06', 'obj', 'June', ],
    ['sep01', 'sep', '', ''],
    ['07', 'obj', 'Jul', ],
    ['sep01', 'sep', '', ''],
    ['08', 'obj', 'Aug', ],
    ['sep01', 'sep', '', ''],
    ['09', 'obj', 'Sep', ],
    ['sep01', 'sep', '', ''],
    ['10', 'obj', 'Oct', ],
    ['sep01', 'sep', '', ''],
    ['11', 'obj', 'Nov', ],
    ['sep01', 'sep', '', ''],
    ['12', 'obj', 'Dec', ],
    ['All', 'obj', 'All']
];
visitors_toolbar.addButtonSelect("months", 6, "Choose Month", month_opts);
var year_opts = [
    ['2016', 'obj', '2016', ],
    ['sep01', 'sep', '', ''],
    ['2017', 'obj', '2017', ],
    ['sep01', 'sep', '', ''],
    ['2018', 'obj', '2018', ],
    ['sep01', 'sep', '', ''],
    ['2019', 'obj', '2019', ],
    ['sep01', 'sep', '', ''],
    ['2020', 'obj', '2020', ],
    ['sep01', 'sep', '', ''],
    ['2020', 'obj', '2021', ],
    ['sep01', 'sep', '', ''],
    ['2020', 'obj', '2022', ]
];

visitors_toolbar.addButtonSelect("years", 7, "Choose Year", year_opts);
visitors_toolbar.attachEvent("onClick", function (id)
{
    var visitor_id = visitors_grid.getSelectedRowId();
    if (id == "add")
    {
        $.post("../data_visitors.php?action=1", function (data) {
            if (data.response)
            {
                dhtmlx.message({
                    text: "New record has been created!",
                    expire: 1000
                });
                visitors_grid.clearAndLoad("../data_visitors.php?action=4");
            }
        }, 'json');
    } else if (id == "refresh")
    {
        visitors_grid.clearAndLoad("../data_visitors.php?action=4");
    } else if (id == "delete")
    {
        dhtmlx.confirm({
            title: "Confirm",
            type: "confirm-warning",
            text: "Are you sure you  want to delete this record?",
            callback: function (y) {
                if (y)
                {

                    $.get("../data_visitors.php?action=2&id=" + visitor_id, function (data) {
                        visitors_grid.deleteRow(visitor_id);
                        dhtmlx.message(data.message);
                    }, 'json');
                } else
                {
                    return false;
                }
            }});
    } else if (id == "export")
    {
        $.post("../data_visitors.php?action=11&visitor_id=" + visitor_id, function (data) {
            if (data.response)
            {
                dhtmlx.message({
                    text: "New record has been created!",
                    expire: 1000
                });
                visitors_grid.clearAndLoad("../data_visitors.php?action=4");
                members_details_grid.clearAndLoad("../data_controller.php?action=5");
            }
        }, 'json');
    } else if (id == "excell")
    {
        window.open("http://" + location.host + "/financials/Controller/excellfiles/visitors.php")
    }
     else if (visitors_toolbar.getParentId(id) == "months")
    {
        visitors_toolbar.setItemText("months", id);
        visitors_grid.clearAndLoad("../data_visitors.php?action=4&month=" + id );
    } else if (visitors_toolbar.getParentId(id) == "years")
    {
        visitors_toolbar.setItemText("years", id);
        visitors_grid.clearAndLoad("../data_visitors.php?action=4&year=" + id);


    }
    
});


var visitorformStructure = [
    // {type: "fieldset", name: "mydata", label: "Visitor Details", width: myWidth * 0.97, offsetLeft: 10, list: [
    {type: "settings", position: "label-left", labelWidth: 150, inputWidth: 150, offsetLeft: 30},
    {type: "input", name: "name", label: "Name"},
    {type: "input", name: "phone", label: "Phone"},
    {type: "input", name: "email", label: "E-mail"},
    {type: "input", name: "address", label: "Address"},
    {type: "combo", name: "gender", label: "Gender", options: [
            {text: "Male", value: "2"},
            {text: "Female", value: "3"}
        ]},
    {type: "combo", name: "marital", label: "Marital Status", options: [
            {text: "Single", value: "14"},
            {text: "Married", value: "15"},
            {text: "Engaged", value: "16"}
        ]},
    {type: "calendar", name: "d_saved", label: "Date Saved", dateFormat: "%Y-%m-%d"},
    {type: "newcolumn"},
    {type: "combo", name: "homecell", label: "Home Cell", options: [
            {text: "Reharboth", value: "Reharboth"},
            {text: "Patmos", value: "Patmos"},
            {text: "Elishadai", value: "Elishadai"},
            {text: "Ebenezar", value: "Ebenezar"},
            {text: "Bethsaida", value: "Bethsaida"},
            {text: "Emanuel", value: "Emanuel"},
        ]},
    {type: "input", name: "p_church", label: "Previous Church Name"},
    {type: "label", label: "Be a member?", list: [
            {type: "radio", name: "m", value: "1", label: "Yes", offsetLeft: 5},
            {type: "radio", name: "m", value: "0", label: "Not Now", offsetLeft: 5}
        ]},
    {type: "label", label: "Are you saved?", list: [
            {type: "radio", name: "s", value: "1", label: "Yes", offsetLeft: 5},
            {type: "radio", name: "s", value: "0", label: "No", offsetLeft: 5, }
        ]},
    {type: "newcolumn"},
    {type: "checkbox", name: "visiting", label: "I am visiting from another church"},
    {type: "label", label: "See the pastor in the office on", list: [
            {type: "radio", name: "see", value: "1", label: "Wednesday", offsetLeft: 5},
            {type: "radio", name: "see", value: "0", label: "Saturday", offsetLeft: 5}
        ]},
    {type: "hidden", name: "moved", label: "Moved to this estate recently"},
    {type: "hidden", name: "agree_t", label: "Agree with Teachings"},
    {type: "hidden", name: "agree_s", label: "Agree Church Support"},
    {type: "newcolumn"},
    {type: 'editor', name: 'prayer', label: 'Prayer Needed:', labelWidth: 90,
        labelLeft: 20, labelTop: 5, inputWidth: 200, inputLeft: 20, inputTop: 20,
        position: 'absolute', labelAlign: 'right', inputHeight: 210, value: ""},
    //   ]},
];

var visitor_membersForm = vistors_Layout.cells("b").attachForm(visitorformStructure);

// //members save Toolbar
visitor_save_Toolbar = vistors_Layout.cells("b").attachToolbar();
visitor_save_Toolbar.addButton("save", 1, "<i class='fa fa-floppy-o '></i> &nbsp;&nbsp; Save");

visitor_save_Toolbar.attachEvent("onClick", function (id)
{
    var reg_no = visitors_grid.getSelectedRowId();
    if (id == "save")
    {
        var id = visitors_grid.getSelectedRowId();
        visitor_membersForm.send("../data_visitors.php?action=13&id=" + id,
                function (loader, response)
                {
                    var data = eval('(' + response + ')');
                    if (data.success)
                    {
                        dhtmlx.message({
                            text: "Data  saved successfully !",
                            expire: 10000
                        });
                        visitors_grid.cells(visitors_grid.getSelectedRowId(), 1).setValue(data.name);
                        visitors_grid.cells(visitors_grid.getSelectedRowId(), 2).setValue(data.phone);
                        visitors_grid.cells(visitors_grid.getSelectedRowId(), 3).setValue(data.email);
                        visitors_grid.cells(visitors_grid.getSelectedRowId(), 4).setValue(data.gender);
                        visitors_grid.cells(visitors_grid.getSelectedRowId(), 5).setValue(data.homecell);
                        visitors_grid.cells(visitors_grid.getSelectedRowId(), 6).setValue(data.marital);
                        visitors_grid.cells(visitors_grid.getSelectedRowId(), 7).setValue(data.category);


                    }
                }, 'json');
    }
});


dedicated_grid = dedicated_Layout.cells("a").attachGrid();
dedicated_grid.setHeader('ID,Name,Place of Birth,Date of Birth,Mother,Father,Date of Dedication,Name of church');
dedicated_grid.setImagePath("http://" + location.host + "/Controller/include/dhtmlx6/skins/web/imgs/");
dedicated_grid.setColumnIds('regno,name,phone,email,gender');
dedicated_grid.attachHeader("#text_filter,#text_filter,#numeric_filter,#text_filter,#text_filter,#text_filter,#text_filter");
dedicated_grid.setSkin('dhx_web');
dedicated_grid.setInitWidthsP('10,*,10,10,10,10,10,10');
dedicated_grid.setColAlign("left,left,left,left,left,left,left,left");
dedicated_grid.enableDragAndDrop(false);
dedicated_grid.enableMercyDrag(false);
dedicated_grid.setColTypes('ro,ed,ed,ed,ed,ed,ed,ed');
dedicated_grid.setDateFormat("%Y-%m-%d %H:%i:%s");
dedicated_grid.setColSorting("int,str,str,str,str,str,str,str");
dedicated_grid.enableSmartRendering("true");
dedicated_grid.enableMultiselect(true);
dedicated_grid.init();

var currentTime = new Date()
var month = currentTime.getMonth() + 1;
var year = currentTime.getFullYear()
dedicated_grid.clearAndLoad("../data_visitors.php?action=8&month=" + month + "&year=" + year);
dedicated_grid.attachEvent("onXLE", do_XLE);

function do_XLE(grid, count) {
    var i = dedicated_grid.getSelectedRowId();
    if ((i == -1) || (i == null)) {
        i = 0;
    }
    dedicated_grid.setSelectedRow(i);
    dedicated_grid.selectRow(i);
}

dedicated_grid.attachEvent("onEditCell", function (stage, rId, cInd, nValue, oValue) {
    var field = visitors_grid.getColumnId(cInd);

    if (stage == 2)
    {
        $.post("../data_visitors.php?action=7", "&field=" + field + "&fieldvalue=" + nValue + "&id=" + rId, function (data) {
            if (data.data.success)
            {
                dedicated_grid.cells(rId, cInd).setValue(nValue);
            }
        }, 'json');
    }
});

dedicated_grid.attachEvent("onSelectStateChanged", function (id) {
    dedicated_membersForm.clear();
    dedicated_membersForm.load("../data_visitors.php?action=15&reg_no=" + id, function () {
    });
});

dedicated_toolbar = dedicated_Layout.cells("a").attachToolbar();
dedicated_toolbar.addButton("add", 1, "<i class='fa fa-plus '></i>&nbsp;&nbsp;New");
dedicated_toolbar.addButton("delete", 2, "<i class='fa fa-trash '></i>&nbsp;&nbsp;Delete");
dedicated_toolbar.addButton("refresh", 3, "<i class='fa fa-refresh fa-spin '></i>&nbsp;&nbsp;Refresh");
dedicated_toolbar.addButton("excell", 4, "<i class='fa fa-file-excel-o' aria-hidden='true'></i>&nbsp;&nbsp;Excell");
var month_opts = [
    ['Today', 'obj', 'Today'],
    ['sep01', 'sep', '', ''],
    ['01', 'obj', 'Jan'],
    ['sep01', 'sep', '', ''],
    ['02', 'obj', 'Feb'],
    ['sep01', 'sep', '', ''],
    ['03', 'obj', 'Mar'],
    ['sep01', 'sep', '', ''],
    ['04', 'obj', 'Apr', ],
    ['sep01', 'sep', '', ''],
    ['05', 'obj', 'May', ],
    ['sep01', 'sep', '', ''],
    ['06', 'obj', 'June', ],
    ['sep01', 'sep', '', ''],
    ['07', 'obj', 'Jul', ],
    ['sep01', 'sep', '', ''],
    ['08', 'obj', 'Aug', ],
    ['sep01', 'sep', '', ''],
    ['09', 'obj', 'Sep', ],
    ['sep01', 'sep', '', ''],
    ['10', 'obj', 'Oct', ],
    ['sep01', 'sep', '', ''],
    ['11', 'obj', 'Nov', ],
    ['sep01', 'sep', '', ''],
    ['12', 'obj', 'Dec', ],
    ['All', 'obj', 'All']
];
dedicated_toolbar.addButtonSelect("months", 6, "Choose Month", month_opts);
var year_opts = [
    ['2016', 'obj', '2016', ],
    ['sep01', 'sep', '', ''],
    ['2017', 'obj', '2017', ],
    ['sep01', 'sep', '', ''],
    ['2018', 'obj', '2018', ],
    ['sep01', 'sep', '', ''],
    ['2019', 'obj', '2019', ],
    ['sep01', 'sep', '', ''],
    ['2020', 'obj', '2020', ],
    ['sep01', 'sep', '', ''],
    ['2020', 'obj', '2021', ],
    ['sep01', 'sep', '', ''],
    ['2020', 'obj', '2022', ]
];

dedicated_toolbar.addButtonSelect("years", 7, "Choose Year", year_opts);

dedicated_toolbar.attachEvent("onClick", function (id)
{
    var visitor_id = dedicated_grid.getSelectedRowId();
    if (id == "add")
    {
        $.post("../data_visitors.php?action=5", function (data) {
            if (data.response)
            {
                dhtmlx.message({
                    text: "New record has been created!",
                    expire: 1000
                });
                dedicated_grid.clearAndLoad("../data_visitors.php?action=8");
            }
        }, 'json');
    } else if (id == "refresh")
    {
        dedicated_grid.clearAndLoad("../data_visitors.php?action=8");
    } else if (id == "delete")
    {
        dhtmlx.confirm({
            title: "Confirm",
            type: "confirm-warning",
            text: "Are you sure you  want to delete this record?",
            callback: function (y) {
                if (y)
                {

                    $.get("../data_visitors.php?action=6&id=" + visitor_id, function (data) {
                        dedicated_grid.deleteRow(visitor_id);
                        dhtmlx.message(data.message);
                    }, 'json');
                } else
                {
                    return false;
                }
            }});
    } else if (id == "excell")
    {
        window.open("http://" + location.host + "/financials/Controller/excellfiles/dedicated.php")
    }
       else if (dedicated_toolbar.getParentId(id) == "months")
    {
        dedicated_toolbar.setItemText("months", id);
        dedicated_grid.clearAndLoad("../data_visitors.php?action=8&month=" + id );
    } else if (dedicated_toolbar.getParentId(id) == "years")
    {
        dedicated_toolbar.setItemText("years", id);
        dedicated_grid.clearAndLoad("../data_visitors.php?action=8&year=" + id);


    }
});

var dedicatedformStructure = [
    {type: "fieldset", name: "mydata", label: "Dedication Details", width: myWidth * 0.94, offsetLeft: 10, list: [
            {type: "settings", position: "label-left", labelWidth: 120, inputWidth: 150, offsetLeft: 20},
            {type: "input", name: "name", label: "Name"},
            {type: "calendar", name: "dob", label: "Date of Birth", dateFormat: "%Y-%m-%d"},
            {type: "input", name: "place", label: "Place of Birth"},
            {type: "newcolumn"},
            {type: "input", name: "mother", label: "Mother"},
            {type: "input", name: "father", label: "Father"},
            {type: "input", name: "church", label: "Church"}

        ]},
];

var dedicated_membersForm = dedicated_Layout.cells("b").attachForm(dedicatedformStructure);
// //members save Toolbar
dedicated_save_Toolbar = dedicated_Layout.cells("b").attachToolbar();
dedicated_save_Toolbar.addButton("save", 1, "<i class='fa fa-floppy-o '></i> &nbsp;&nbsp; Save");

dedicated_save_Toolbar.attachEvent("onClick", function (id)
{
    var reg_no = dedicated_grid.getSelectedRowId();
    if (id == "save")
    {
        var id = dedicated_grid.getSelectedRowId();
        dedicated_membersForm.send("../data_visitors.php?action=14&id=" + id,
                function (loader, response)
                {
                    var data = eval('(' + response + ')');
                    if (data.success)
                    {
                        dhtmlx.message({
                            text: "Data  saved successfully !",
                            expire: 10000
                        });

                        dedicated_grid.cells(dedicated_grid.getSelectedRowId(), 1).setValue(data.name);
                        dedicated_grid.cells(dedicated_grid.getSelectedRowId(), 2).setValue(data.place);
                        dedicated_grid.cells(dedicated_grid.getSelectedRowId(), 3).setValue(data.dob);
                        dedicated_grid.cells(dedicated_grid.getSelectedRowId(), 4).setValue(data.mother);
                        dedicated_grid.cells(dedicated_grid.getSelectedRowId(), 5).setValue(data.father);
                        dedicated_grid.cells(dedicated_grid.getSelectedRowId(), 7).setValue(data.church);
                    }
                }, 'json');
    }
});
function importcontacts()
{
    var members_PopUp = new dhtmlXWindows({
        image_path: "http://" + location.host + "/financials/Controller/include/dhtmlx6/skins/terrace/imgs/dhxwins_terrace/",
        skin: "dhx_terrace"
    });
    members_PopUp.createWindow({
        id: "members",
        left: 242,
        top: 80,
        width: 400,
        height: 400,
        //center:true,
        onClose: function () {
            alert("I'm closed");
        }
    });
    members_PopUp.window("members").setText("List of members");
    members_PopUp.window("members").button("park").hide();
    members_PopUp.window("members").button("minmax").hide();
    members_PopUp.window("members").button("close").hide();

    member_list = members_PopUp.window("members").attachGrid();
    member_list.setHeader(',Reg No,Name');
    member_list.setImagePath("http://" + location.host + "/financials/Controller/include/dhtmlx6/skins/web/imgs/");
    member_list.attachHeader(",#text_filter,#text_filter");
    member_list.setColumnIds('id,reg_no,name');
    member_list.setSkin('dhx_web');
    member_list.setInitWidthsP('10,40,50');
    member_list.setColAlign("left,left,left");
    member_list.enableDragAndDrop(false);
    member_list.enableMercyDrag(false);
    member_list.setColTypes('ch,ro,ro'); //dhxCalendar
    member_list.setDateFormat("%Y-%m-%d %H:%i:%s");
    member_list.setColSorting("int,str,str");
    member_list.enableSmartRendering("true");
    member_list.enableMultiselect(true);
    member_list.init();
    member_list.clearAndLoad("../data_visitors.php?action=9");
    member_list.attachEvent("onXLE", doeditor_gridlistselectionXLE);

    function doeditor_gridlistselectionXLE(grid, count) {
        var i = member_list.getSelectedRowId();
        if ((i == -1) || (i == null)) {
            i = 0;
        }
        member_list.setSelectedRow(i);
        member_list.selectRow(i);
    }


    list_toolbar = members_PopUp.window("members").attachToolbar();
    list_toolbar.addButton("add", 1, "<i class='fa fa-plus-circle'></i>&nbsp;&nbsp;Add Selected");
    list_toolbar.addSeparator("sep2", 2);
    list_toolbar.addButton("cancel", 3, "<i class='fa fa-times'></i>&nbsp;&nbsp;Cancel");

    list_toolbar.attachEvent("onClick", function (id)
    {
        var selected_id = member_list.getCheckedRows(0);
        // var home_cell=cell_tree.getSelectedItemId();
        if (id == "add")
        {
            var postVars = {
                "selected_id": member_list.getCheckedRows(0)


            };
            $.post("../data_visitors.php?action=10", postVars, function (data) {
                if (data.response)
                {
                    dhtmlx.message({
                        text: "New record has been created!",
                        expire: 1000
                    });
                    members_PopUp.window("members").hide();
                    baptised_grid.clearAndLoad("../data_visitors.php?action=17");
                }
            }, 'json');
        } else if (id == "cancel")
        {
            members_PopUp.window("members").hide();
        }
    });
}
//baptised
baptised_grid = baptised_Layout.cells("a").attachGrid();
baptised_grid.setHeader('No,Name,Date of birth,Date of Baptism,Place,Minister');
baptised_grid.setImagePath("http://" + location.host + "/Controller/include/dhtmlx6/skins/web/imgs/");
baptised_grid.setColumnIds('regno,name,dob,dateofbaptism,place,minister');
baptised_grid.attachHeader("#text_filter,#text_filter,#numeric_filter,#text_filter,#text_filter,#numeric_filter");
baptised_grid.setSkin('dhx_web');
baptised_grid.setInitWidthsP('15,*,15,15,10,10');
baptised_grid.setColAlign("left,left,left,left,left,left");
baptised_grid.enableDragAndDrop(false);
baptised_grid.enableMercyDrag(false);
baptised_grid.setColTypes('ro,ed,ed,ed,ed,ed');
baptised_grid.setDateFormat("%Y-%m-%d %H:%i:%s");
baptised_grid.setColSorting("int,str,str,str,str,str");
baptised_grid.enableSmartRendering("true");
baptised_grid.enableMultiselect(true);
baptised_grid.init();
var currentTime = new Date()
var month = currentTime.getMonth() + 1;
var year = currentTime.getFullYear()
baptised_grid.clearAndLoad("../data_visitors.php?action=17&month=" + month + "&year=" + year);
baptised_grid.attachEvent("onXLE", do_selectionXLE);


baptised_grid.attachEvent("onEditCell", function (stage, rId, cInd, nValue, oValue) {
    var field = baptised_grid.getColumnId(cInd);

    if (stage == 2)
    {
        $.post("../data_visitors.php?action=16", "&field=" + field + "&fieldvalue=" + nValue + "&reg_no=" + rId, function (data) {
            if (data.data.success)
            {
                baptised_grid.cells(rId, cInd).setValue(nValue);
            }
        }, 'json');
    }

});

baptised_grid.attachEvent("onSelectStateChanged", function (id) {
    baptised_membersForm.clear();
    baptised_membersForm.load("../data_visitors.php?action=18&reg_no=" + id, function () {
    });
});
var baptisedformStructure = [
    {type: "fieldset", name: "mydata", label: "Baptised Details", width: myWidth * 0.94, offsetLeft: 10, list: [
            {type: "settings", position: "label-left", labelWidth: 120, inputWidth: 150, offsetLeft: 20},
            {type: "input", name: "no", label: "Number"},
            {type: "input", name: "name", label: "Name"},
            {type: "calendar", name: "dob", label: "Date of Birth", dateFormat: "%Y-%m-%d"},
            {type: "newcolumn"},
            {type: "input", name: "place", label: "Place"},
            {type: "input", name: "minister", label: "Minister"},
            {type: "calendar", name: "dateofbaptism", label: "Date of Baptism", dateFormat: "%Y-%m-%d"},
        ]},
];
var baptised_membersForm = baptised_Layout.cells("b").attachForm(baptisedformStructure);

baptised_toolbar = baptised_Layout.cells("a").attachToolbar();
baptised_toolbar.addButton("import", 1, "<i class='fa fa-download'></i>&nbsp;&nbsp;Import");
baptised_toolbar.addButton("delete", 2, "<i class='fa fa-trash '></i>&nbsp;&nbsp;Delete");
baptised_toolbar.addButton("excell", 4, "<i class='fa fa-file-excel-o' aria-hidden='true'></i>&nbsp;&nbsp;Excell");
var month_opts = [
    ['Today', 'obj', 'Today'],
    ['sep01', 'sep', '', ''],
    ['01', 'obj', 'Jan'],
    ['sep01', 'sep', '', ''],
    ['02', 'obj', 'Feb'],
    ['sep01', 'sep', '', ''],
    ['03', 'obj', 'Mar'],
    ['sep01', 'sep', '', ''],
    ['04', 'obj', 'Apr', ],
    ['sep01', 'sep', '', ''],
    ['05', 'obj', 'May', ],
    ['sep01', 'sep', '', ''],
    ['06', 'obj', 'June', ],
    ['sep01', 'sep', '', ''],
    ['07', 'obj', 'Jul', ],
    ['sep01', 'sep', '', ''],
    ['08', 'obj', 'Aug', ],
    ['sep01', 'sep', '', ''],
    ['09', 'obj', 'Sep', ],
    ['sep01', 'sep', '', ''],
    ['10', 'obj', 'Oct', ],
    ['sep01', 'sep', '', ''],
    ['11', 'obj', 'Nov', ],
    ['sep01', 'sep', '', ''],
    ['12', 'obj', 'Dec', ],
    ['All', 'obj', 'All']
];
baptised_toolbar.addButtonSelect("months", 6, "Choose Month", month_opts);
var year_opts = [
    ['2016', 'obj', '2016', ],
    ['sep01', 'sep', '', ''],
    ['2017', 'obj', '2017', ],
    ['sep01', 'sep', '', ''],
    ['2018', 'obj', '2018', ],
    ['sep01', 'sep', '', ''],
    ['2019', 'obj', '2019', ],
    ['sep01', 'sep', '', ''],
    ['2020', 'obj', '2020', ],
    ['sep01', 'sep', '', ''],
    ['2020', 'obj', '2021', ],
    ['sep01', 'sep', '', ''],
    ['2020', 'obj', '2022', ]
];

baptised_toolbar.addButtonSelect("years", 7, "Choose Year", year_opts);
baptised_toolbar.attachEvent("onClick", function (id)
{
    var bat_id = baptised_grid.getSelectedRowId();
    if (id == "import")
    {
        importcontacts();
    } else if (id == "delete")
    {
        dhtmlx.confirm({
            title: "Confirm",
            type: "confirm-warning",
            text: "Are you sure you  want to delete this record?",
            callback: function (y) {
                if (y)
                {

                    $.get("../data_visitors.php?action=20&id=" + bat_id, function (data) {
                        baptised_grid.deleteRow(bat_id);
                        dhtmlx.message(data.message);
                    }, 'json');
                } else
                {
                    return false;
                }
            }});
    } else if (id == "excell")
    {
        window.open("http://" + location.host + "/financials/Controller/excellfiles/baptised.php");
    }
       else if (baptised_toolbar.getParentId(id) == "months")
    {
        baptised_toolbar.setItemText("months", id);
        baptised_grid.clearAndLoad("../data_visitors.php?action=17&month=" + id );
    } else if (baptised_toolbar.getParentId(id) == "years")
    {
        baptised_toolbar.setItemText("years", id);
        baptised_grid.clearAndLoad("../data_visitors.php?action=17&year=" + id);


    }

});

baptised_save_Toolbar = baptised_Layout.cells("b").attachToolbar();
baptised_save_Toolbar.addButton("save", 1, "<i class='fa fa-floppy-o '></i> &nbsp;&nbsp; Save");

baptised_save_Toolbar.attachEvent("onClick", function (id)
{

    if (id == "save")
    {
        var id = baptised_grid.getSelectedRowId();
        baptised_membersForm.send("../data_visitors.php?action=19&id=" + id,
                function (loader, response)
                {
                    var data = eval('(' + response + ')');
                    if (data.success)
                    {
                        dhtmlx.message({
                            text: "Data  saved successfully !",
                            expire: 10000
                        });
                        baptised_grid.cells(baptised_grid.getSelectedRowId(), 1).setValue(data.name);
                        baptised_grid.cells(baptised_grid.getSelectedRowId(), 2).setValue(data.dateofbaptism);
                        baptised_grid.cells(baptised_grid.getSelectedRowId(), 3).setValue(data.dob);
                        baptised_grid.cells(baptised_grid.getSelectedRowId(), 4).setValue(data.place);
                        baptised_grid.cells(baptised_grid.getSelectedRowId(), 5).setValue(data.minister);



                    }
                }, 'json');
    }
});
var access = document.getElementById("accessrights").value;
if (access == 2)
{
    membersTopToolbar.hideItem("delete");
    memberslowerToolbar.hideItem("save");
    members_save_Toolbar.hideItem("save");
    members_contribution_Toolbar.hideItem("delete");
    visitor_save_Toolbar.hideItem("save");
    visitors_toolbar.hideItem("delete");
    visitors_toolbar.hideItem("export");
    dedicated_save_Toolbar.hideItem("save");
    dedicated_toolbar.hideItem("delete");
    baptised_toolbar.hideItem("import");
    baptised_save_Toolbar.hideItem("save");
    baptised_toolbar.hideItem("delete");
    members_details_grid.enableEditEvents(false, false, false);
    members_contribution_grid.enableEditEvents(false, false, false);
    visitors_grid.enableEditEvents(false, false, false);
    members_contribution_grid.enableEditEvents(false, false, false);
    baptised_grid.enableEditEvents(false, false, false);
    member_list.enableEditEvents(false, false, false);
    dedicated_grid.enableEditEvents(false, false, false);
    membersForm.setReadonly("upload", true);

} 