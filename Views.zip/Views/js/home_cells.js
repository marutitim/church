var myWidth;
var myHeight;

if (typeof (window.innerWidth) == 'number') {

    //Non-IE 

    myWidth = window.innerWidth;
    myHeight = window.innerHeight;

} else if (document.documentElement && (document.documentElement.clientWidth || document.documentElement.clientHeight)) {

    //IE 6+ in 'standards compliant mode' 

    myWidth = document.documentElement.clientWidth;
    myHeight = document.documentElement.clientHeight;

} else if (document.body && (document.body.clientWidth || document.body.clientHeight)) {

    //IE 4 compatible 

    myWidth = document.body.clientWidth;
    myHeight = document.body.clientHeight;

}
//main home cell layout
var home_cells_layout = new dhtmlXLayoutObject("homecells_layout", "2U", "dhx_terrace");
home_cells_layout.cells("a").setText("Home Cells");
home_cells_layout.cells("a").setWidth(myWidth*0.2);
home_cells_layout.cells("b").setText("Members");
//home_cells_layout.cells("c").setText("Remarks");

//members 

home_cells_grid = home_cells_layout.cells("b").attachGrid();
home_cells_grid.setHeader('No,Name,Telephone,Gender,Status,Position');
home_cells_grid.setImagePath("http://" + location.host + "/financials/Controller/include/dhtmlx6/skins/web/imgs/");
home_cells_grid.setColumnIds('id,name,cl,cm,pvc,position');
home_cells_grid.setSkin('dhx_web');
home_cells_grid.setInitWidthsP('15,*,20,20,15,0');
home_cells_grid.setColAlign("left,left,left,left,left,left");
home_cells_grid.enableDragAndDrop(false);
home_cells_grid.enableMercyDrag(false);
home_cells_grid.setColTypes('ro,ro,ro,ro,ro,ro'); //dhxCalendar
home_cells_grid.setDateFormat("%Y-%m-%d %H:%i:%s");
home_cells_grid.setColSorting("in,str,str,str,str,str");
home_cells_grid.enableSmartRendering("true");
home_cells_grid.enableMultiselect(true);
home_cells_grid.init();




home_cells_grid.attachEvent("onEditCell", function(stage, rId, cInd, nValue, oValue) {
    var field = home_cells_grid.getColumnId(cInd);

    if (stage == 2)
    {
        $.post("../data_controller.php?action=15", "&field=" + field + "&fieldvalue=" + nValue + "&faculty_id=" + rId, function(data) {
            if (data.data.success)
            {
                home_cells_grid.cells(rId, cInd).setValue(nValue);
            }
        }, 'json');
    }
    else if (field == "active")
    {
        if (typeof nValue == "undefined")
        {
            var cell = home_cells_grid.cells(rId, cInd);
            var cValue = cell.getValue();

            if (cValue == 1)
            {
                cell.setValue(0);
                $.post("../data_controller.php?action=15", "&field=" + field + "&fieldvalue=" + 0 + "&faculty_id=" + rId, function(data) {
                    if (data.success)
                    {

                    }
                });

            }
            else if (cValue == 0)
            {
                home_cells_grid.selectRowById(rId);
                cell.setValue(1);
                $.post("../data_controller.php?action=15", "&field=" + field + "&fieldvalue=" + 1 + "&faculty_id=" + rId, function(data) {
                    if (data.success)
                    {

                    }
                });
            }
        }
    }
});



var cell_tree =home_cells_layout.cells("a").attachTree();
cell_tree.setSkin('dhx_web');
cell_tree.setImagePath("http://" + location.host + "/financials/Controller/include/dhtmlx6/skins/web/imgs/dhxtree_web/");
cell_tree.enableSmartXMLParsing(true);
cell_tree.enableCheckBoxes(true);
cell_tree.enableDragAndDrop(true);
cell_tree.enableThreeStateCheckboxes(false);
cell_tree.enableMultiselection(1, 0);
//cell_tree.enableTreeImages(false);
//cell_tree.enableTreeLines(true);
cell_tree.deleteChildItems(0);// before  the tree loads the curent tree  is deleted
cell_tree.loadXML("http://" + location.host + "/financials/Controller/data_controller.php?action=17", function() {
    cell_tree.openAllItems(0);
});

cell_tree.attachEvent("onSelect", function(id, mode){
   home_cells_grid.clearAndLoad("../data_controller.php?action=18&id="+id);
});

homecellmembers_toolbar = home_cells_layout.cells("b").attachToolbar();
homecellmembers_toolbar.addButton("excell", 1, "<i class='fa fa-file-excel-o' aria-hidden='true'></i>&nbsp;&nbsp;Excell");

homecellmembers_toolbar.attachEvent("onClick", function (id)
{
    var cell_no=cell_tree.getSelectedItemId();

    if (id == "excell")
    {
        window.open("http://" + location.host + "/financials/Controller/excellfiles/homecell.php?cell_no="+cell_no);
    }

});
var access = document.getElementById("accessrights").value;
if (access == 1 || access == 2)
{
    home_cells_toolbar.hideItem("new");
    home_cells_toolbar.hideItem("delete");
    coursedocumentToolbar.hideItem("save");
    home_cells_grid.enableEditEvents(false, false, false);
}

//statistics

//statistics_grid = home_cells_tabber.cells("statistics").attachGrid();
//statistics_grid.setHeader('No,Name,Telephone,Gender,Status,Position');
//statistics_grid.setImagePath("http://" + location.host + "/financials/Controller/include/dhtmlx6/skins/web/imgs/");
//statistics_grid.setColumnIds('id,name,cl,cm,pvc,position');
//statistics_grid.setSkin('dhx_web');
//statistics_grid.setInitWidthsP('5,25,20,20,15,15');
//statistics_grid.setColAlign("left,left,left,left,left,left");
//statistics_grid.enableDragAndDrop(false);
//statistics_grid.enableMercyDrag(false);
//statistics_grid.setColTypes('ed,ed,ed,combo,combo,ed'); //dhxCalendar
//statistics_grid.setDateFormat("%Y-%m-%d %H:%i:%s");
//statistics_grid.setColSorting("in,str,str,str,str,str");
//statistics_grid.enableSmartRendering("true");
//statistics_grid.enableMultiselect(true);
//statistics_grid.init();
//statistics_grid.clearAndLoad("../data_controller.php?action=21");
//
////statistics combo
//statistics_Toolbar =home_cells_tabber.cells("statistics").attachToolbar();
//var statistics = [
//    ['new', 'obj', 'New'],
//    ['sep01', 'sep', '', ''],
//    ['01', 'obj', 'Absentee'],
//    ['sep01', 'sep', '', ''],
//    ['02', 'obj', 'Got Saved'],
//    ['sep01', 'sep', '', ''],
//    ['03', 'obj', 'Adults'],
//    ['sep01', 'sep', '', ''],
//    ['04', 'obj', 'Children', ]
//];
//statistics_Toolbar.addButtonSelect("statistics", 1, "Select Statistics", statistics);
//
////projects
//
//var projects=home_cells_tabber.cells("projects").attachURL("http://" + location.host + "/financials/Controller/pages/projects.php");
//
//
//

