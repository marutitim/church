var myWidth;
var myHeight;
var manualIframe;
if (typeof (window.innerWidth) == 'number') {

    //Non-IE 

    myWidth = window.innerWidth;
    myHeight = window.innerHeight;

} else if (document.documentElement && (document.documentElement.clientWidth || document.documentElement.clientHeight)) {

    //IE 6+ in 'standards compliant mode' 

    myWidth = document.documentElement.clientWidth;
    myHeight = document.documentElement.clientHeight;

} else if (document.body && (document.body.clientWidth || document.body.clientHeight)) {

    //IE 4 compatible 

    myWidth = document.body.clientWidth;
    myHeight = document.body.clientHeight;

}

var assets_layout = new dhtmlXLayoutObject("assests_layout", "3U", "dhx_terrace");
assets_layout.cells("a").setText("Asset Picture");
assets_layout.cells("b").setText("");
assets_layout.cells("c").setText("Assest List");
assets_layout.cells("a").setHeight(myHeight * 0.5);


assets_tabber = assets_layout.cells("b").attachTabbar();
assets_tabber.setSkin('dhx_terrace');
assets_tabber.addTab("details", "Assests Details");
assets_tabber.addTab("manual", "Assets Manual");
assets_tabber.tabs("details").setActive();
assets_tabber.setArrowsMode('auto');



//assets grid
assets_grid = assets_layout.cells("c").attachGrid();
assets_grid.setImagePath("http://" + location.host + "/Controller/include/dhtmlx6/skins/web/imgs/");
assets_grid.setHeader('#,Name,Value,Location,status,Date bought,Serial Number,Quantity,Person In charge');
assets_grid.attachHeader("#text_filter,#text_filter,#text_filter,#text_filter,#text_filter,#text_filter,#text_filter,#text_filter,#text_filter");
assets_grid.setColumnIds('id,name,value,location,status,Dateb,Serial,quality,Person');
assets_grid.setSkin('dhx_web');
assets_grid.setInitWidthsP('5,10,10,10,10,10,10,10,*');
assets_grid.setColAlign("left,left,left,left,left,left,left,left,left");
assets_grid.enableDragAndDrop(false);
assets_grid.enableMercyDrag(false);
assets_grid.setColTypes('ro,ed,ed,ed,ed,ed,ed,ed,ed'); //dhxCalendar
assets_grid.setDateFormat("%Y-%m-%d %H:%i:%s");
assets_grid.setColSorting("str,str,str,str,str,str,str,str,str");
assets_grid.enableSmartRendering("true");
assets_grid.enableMultiselect(true);
assets_grid.init();
var currentTime = new Date()
var month = currentTime.getMonth() + 1;
var year = currentTime.getFullYear()
assets_grid.clearAndLoad("../data_controller.php?action=26&month=" + month + "&year=" + year);
assets_grid.attachEvent("onXLE", doassets_gridlistselectionXLE);

function doassets_gridlistselectionXLE(grid, count) {
    var i = assets_grid.getSelectedRowId();
    if ((i == -1) || (i == null)) {
        i = 0;
    }
    assets_grid.setSelectedRow(i);
    assets_grid.selectRow(i);
}


assets_grid.attachEvent("onSelectStateChanged", function (id) {

    assets_layout.cells("a").attachURL("http://" + window.location.hostname + "/financials/Views/slider/index.php?id=" + id);
    assestsForm.clear();
    assestsForm.load("../data_controller.php?action=28&id=" + id, function () { });
    manualIframe.contentWindow.tinymce.activeEditor.setContent('');
    $.get("../data_controller.php?action=52&id=" + id, function (data)
    {
        if (data.response)
        {
            manualIframe.contentWindow.tinymce.activeEditor.setContent(data.response);

        }
    }, 'json');
});

assets_grid.attachEvent("onEditCell", function (stage, rId, cInd, nValue, oValue) {
    var field = assets_grid.getColumnId(cInd);

    if (stage == 2)
    {
        $.post("../data_controller.php?action=24", "&field=" + field + "&fieldvalue=" + nValue + "&assest_id=" + rId, function (data) {
            if (data.data.success)
            {
                assets_grid.cells(rId, cInd).setValue(nValue);
            }
        }, 'json');
    }
});

//asset list toolbar
assets_toolbar = assets_layout.cells("c").attachToolbar();
assets_toolbar.addButton("add", 1, "<i class='fa fa-plus '></i>&nbsp;&nbsp;Add Assest");
assets_toolbar.addButton("delete", 2, "<i class='fa fa-trash '></i>&nbsp;&nbsp;Remove Assest");
assets_toolbar.addButton("excell", 3, "<i class='fa fa-file-excel-o' aria-hidden='true'></i>&nbsp;&nbsp;Excell");
var month_opts = [
    ['Today', 'obj', 'Today'],
    ['sep01', 'sep', '', ''],
    ['01', 'obj', 'Jan'],
    ['sep01', 'sep', '', ''],
    ['02', 'obj', 'Feb'],
    ['sep01', 'sep', '', ''],
    ['03', 'obj', 'Mar'],
    ['sep01', 'sep', '', ''],
    ['04', 'obj', 'Apr', ],
    ['sep01', 'sep', '', ''],
    ['05', 'obj', 'May', ],
    ['sep01', 'sep', '', ''],
    ['06', 'obj', 'June', ],
    ['sep01', 'sep', '', ''],
    ['07', 'obj', 'Jul', ],
    ['sep01', 'sep', '', ''],
    ['08', 'obj', 'Aug', ],
    ['sep01', 'sep', '', ''],
    ['09', 'obj', 'Sep', ],
    ['sep01', 'sep', '', ''],
    ['10', 'obj', 'Oct', ],
    ['sep01', 'sep', '', ''],
    ['11', 'obj', 'Nov', ],
    ['sep01', 'sep', '', ''],
    ['12', 'obj', 'Dec', ],
    ['All', 'obj', 'All']
];
assets_toolbar.addButtonSelect("months", 5, "Choose Month", month_opts);

var year_opts = [
    ['2016', 'obj', '2016', ],
    ['sep01', 'sep', '', ''],
    ['2017', 'obj', '2017', ],
    ['sep01', 'sep', '', ''],
    ['2018', 'obj', '2018', ],
    ['sep01', 'sep', '', ''],
    ['2019', 'obj', '2019', ],
    ['sep01', 'sep', '', ''],
    ['2020', 'obj', '2020', ],
    ['sep01', 'sep', '', ''],
    ['2020', 'obj', '2021', ],
    ['sep01', 'sep', '', ''],
    ['2020', 'obj', '2022', ]
];

assets_toolbar.addButtonSelect("years", 6, "Choose Year", year_opts);

//asset form toolbar
assets_form_toolbar = assets_tabber.cells("details").attachToolbar();
assets_form_toolbar.addButton("save", 1, "<i class='fa fa-floppy-o '></i> &nbsp;&nbsp; Save");


//asset manual toolbar
assets_manual_toolbar = assets_tabber.cells("manual").attachToolbar();
assets_manual_toolbar.addButton("save", 1, "<i class='fa fa-floppy-o '></i> &nbsp;&nbsp; Save");

//asset list toolbar
assets_pics_toolbar = assets_layout.cells("a").attachToolbar();
assets_pics_toolbar.addButton("upload", 1, "<i class='fa fa-upload'></i> &nbsp;&nbsp; Upload asset Picture");

assets_toolbar.attachEvent("onClick", function (id)
{
    var assests_id = assets_grid.getSelectedRowId();
    if (id == "add")
    {
        $.post("../data_controller.php?action=22", function (data) {
            if (data.response)
            {
                dhtmlx.message({
                    text: "New record has been created!",
                    expire: 1000
                });
                assets_grid.clearAndLoad("../data_controller.php?action=26");
            }
        }, 'json');
    } else if (id == "delete")
    {
        dhtmlx.confirm({
            title: "Confirm",
            type: "confirm-warning",
            text: "Are you sure you  want to delete this record?",
            callback: function (y) {
                if (y)
                {

                    $.get("../data_controller.php?action=25&assest_id=" + assests_id, function (data) {
                        assets_grid.deleteRow(assests_id);
                        dhtmlx.message(data.message);
                    }, 'json');
                } else
                {
                    return false;
                }
            }});
    } else if (id == "excell")
    {
        window.open("http://" + location.host + "/financials/Controller/excellfiles/assets.php");
    } else if (assets_toolbar.getParentId(id) == "months")
    {
        assets_toolbar.setItemText("months", id);
        manualIframe.contentWindow.tinymce.activeEditor.setContent('');
        assets_grid.clearAndLoad("../data_controller.php?action=26&month=" + id);
    } else if (assets_toolbar.getParentId(id) == "years")
    {
        manualIframe.contentWindow.tinymce.activeEditor.setContent('');
        assets_toolbar.setItemText("years", id);
        assets_grid.clearAndLoad("../data_controller.php?action=26&year=" + id);


    }
});

assets_pics_toolbar.attachEvent("onClick", function (id)
{
    if (id == "upload")
    {
        uploadimgs();
    }
});
function uploadimgs() {
    var assests_id = assets_grid.getSelectedRowId();
    if (assests_id > 0 || typeof assests_id !== 'undefined') {
        dhxCRMWins = new dhtmlXWindows();
        dhxCRMImageUploadWins = dhxCRMWins.createWindow("assetsimagesupload", '', '', 500, 300);
        dhxCRMImageUploadWins.button("park").hide();
        dhxCRMImageUploadWins.button("minmax").hide();
        dhxCRMImageUploadWins.denyResize();
        dhxCRMImageUploadWins.denyMove();
        dhxCRMImageUploadWins.setModal(true);
        dhxCRMImageUploadWins.centerOnScreen();
        dhxCRMImageUploadWins.setText("Upload Images");
        dhxCRMImageUploadWins.attachEvent("onClose", function (w)
        {
            w.detachObject();
            w.hide();
            w.setModal(false);
        });
        crmImageFormData = [{
                type: "fieldset",
                label: "Select Images",
                list: [{
                        type: 'hidden',
                        name: 'id',
                        value: assests_id
                    }, {
                        type: "upload",
                        name: "myFiles",
                        inputWidth: 300,
                        url: "../uploadimages.php?id=" + assests_id,
                        swfPath: "../../../dhtmlx3.6pro/dhtmlxForm/codebase/ext/uploader.swf"
                    }]
            }];
        crmImageForm = dhxCRMImageUploadWins.attachForm(crmImageFormData);
        crmImageForm.attachEvent("onUploadFile", function (realName, serverName) {

        });
        crmImageForm.attachEvent("onUploadComplete", function (count) {
            dhtmlx.alert({title: 'Success', text: "<b>onUploadComplete</b> " + count + " file" + (count > 1 ? "s were" : " was") + " uploaded"});
            
            dhxCRMImageUploadWins.detachObject();
            dhxCRMImageUploadWins.hide();
            dhxCRMImageUploadWins.setModal(false);
            
            var currentTime = new Date()
            var month = currentTime.getMonth() + 1;
            var year = currentTime.getFullYear()
            assets_grid.clearAndLoad("../data_controller.php?action=26&month=" + month + "&year=" + year);

        });
    } else {
        dhtmlx.alert({title: 'Warning', text: 'Select Asset Id'});
    }
}

//
var formStructure = [
    // {type: "fieldset", name: "mydata", label: "Assets Details", height: myHeight * 0.9, offsetLeft: 10, list: [
    {type: "settings", position: "label-left", labelWidth: 100, inputWidth: 120, offsetLeft: 10},
    {type: "input", name: "name", label: "Name"},
    {type: "input", name: "value", label: "Value"},
    {type: "input", name: "location", label: "Location"},
    {type: "combo", name: "status", label: "Status",
        options: [
            {text: "Good", value: "good"},
            {text: "Destroyed", value: "Destroyed"},
            {text: "Lost", value: "Lost"},
            {text: "Borrowed", value: "Borrowed"},
            {text: "Rent", value: "Rent"}
        ]},
    {type: "newcolumn"},
    {type: "calendar", name: "dateb", label: "Date Bought", dateFormat: "%Y-%m-%d"},
    {type: "input", name: "serial", label: "Serial Number"},
    {type: "input", name: "quality", label: "Quantity"},
    {type: "combo", name: "person", label: "Person In Charge"}
    //]},
];

var assestsForm = assets_tabber.cells("details").attachForm(formStructure);
//
var personcombo = assestsForm.getCombo("person");

personcombo.load("../data_controller.php?action=31")
var personcombo = assestsForm.getCombo("person");
assets_form_toolbar.attachEvent("onClick", function (id)
{
    var assests_id = assets_grid.getSelectedRowId();
    if (id == "save")
    {

        assestsForm.send("../data_controller.php?action=27&assests_id=" + assests_id,
                function (loader, response)
                {
                    var data = eval('(' + response + ')');

                    if (data.success = 'true')
                    {

                        dhtmlx.message({
                            text: "Data  saved successfully !",
                            expire: 10000
                        });
                        assets_grid.cells(assets_grid.getSelectedRowId(), 1).setValue(data.name);
                        assets_grid.cells(assets_grid.getSelectedRowId(), 2).setValue(data.value);
                        assets_grid.cells(assets_grid.getSelectedRowId(), 3).setValue(data.location);
                        assets_grid.cells(assets_grid.getSelectedRowId(), 4).setValue(data.status);
                        assets_grid.cells(assets_grid.getSelectedRowId(), 5).setValue(data.dateb);
                        assets_grid.cells(assets_grid.getSelectedRowId(), 6).setValue(data.serial);
                        assets_grid.cells(assets_grid.getSelectedRowId(), 7).setValue(data.quality);
                        assets_grid.cells(assets_grid.getSelectedRowId(), 8).setValue(data.person);
                    }
                }, 'json');
    }
});

assets_manual_toolbar.attachEvent("onClick", function (id)
{
    var assests_id = assets_grid.getSelectedRowId();
    if (id == "save")
    {

        var postvar = {
            manual: manualIframe.contentWindow.tinyMCE.activeEditor.getContent({format: 'html'}),
            assests_id: assests_id,
        }



        $.post("../data_controller.php?action=51", postvar, function (data) {

            if (data.response)
            {
                dhtmlx.message({
                    text: "Records saved successfully!",
                    expire: 1000
                });
            }


        }, 'json');

    }
});
//
//

var manual_documentationCell = assets_tabber.cells("manual");
manual_documentationCell.attachURL("http://" + location.host + "/financials/Views/plugin/document.php", false,
        {report_content: ''});
assets_tabber.attachEvent("onContentLoaded", function (id) {
    manualIframe = assets_tabber.cells(id).getFrame();
});
////
//
//
var access = document.getElementById("accessrights").value;
if (access == 2)
{
    assets_toolbar.hideItem("add");
    assets_toolbar.hideItem("delete");
    assets_form_toolbar.hideItem("save");
    assets_pics_toolbar.hideItem("upload");
    assets_grid.enableEditEvents(false, false, false);


}
//
//       