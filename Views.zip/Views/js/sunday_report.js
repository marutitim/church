/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


var myWidth;
var myHeight;

if (typeof (window.innerWidth) == 'number') {

    //Non-IE 

    myWidth = window.innerWidth;
    myHeight = window.innerHeight;

} else if (document.documentElement && (document.documentElement.clientWidth || document.documentElement.clientHeight)) {

    //IE 6+ in 'standards compliant mode' 

    myWidth = document.documentElement.clientWidth;
    myHeight = document.documentElement.clientHeight;

} else if (document.body && (document.body.clientWidth || document.body.clientHeight)) {

    //IE 4 compatible 

    myWidth = document.body.clientWidth;
    myHeight = document.body.clientHeight;

}
var sunday_main_layout = new dhtmlXLayoutObject("main_layout", "2E", "dhx_terrace");
sunday_main_layout.cells("a").hideHeader();
sunday_main_layout.cells("b").hideHeader();
sunday_main_layout.cells("a").setHeight(myHeight * 0.4)

var sunday_tab = sunday_main_layout.cells("b").attachTabbar();
sunday_tab.setSkin('dhx_terrace');
sunday_tab.addTab("income", "Income");
sunday_tab.addTab("expenses", "Expenditures");
sunday_tab.addTab("account", "Account Status");
sunday_tab.tabs("income").setActive();
sunday_tab.setArrowsMode('auto');

var income_layout = sunday_tab.cells("income").attachLayout("2U");
income_layout.cells("a").hideHeader();
income_layout.cells("b").hideHeader();

var expenditure_layout = sunday_tab.cells("expenses").attachLayout("2U");
expenditure_layout.cells("a").hideHeader();
expenditure_layout.cells("b").hideHeader();

//sunday grid
sunday_grid = income_layout.cells("a").attachGrid();
sunday_grid.setHeader('Date,+ Men,+ Women,+ Youth,+ Children,+ Total Tithe,+ Total Thanksgiving,+ Total Prophetic Seed,+ Total Sunday Offering');
sunday_grid.setImagePath("http://" + location.host + "/Controller/include/dhtmlx6/skins/web/imgs/");
sunday_grid.setColumnIds('date,men,women,youth,children,tithe,thanks,seed,total');
sunday_grid.attachHeader("#text_filter,#numeric_filter,#numeric_filter,#numeric_filter,#numeric_filter,#text_filter,#numeric_filter,#numeric_filter,#numeric_filter,#numeric_filter");
sunday_grid.setSkin('dhx_web');
sunday_grid.setInitWidthsP('0,10,10,10,10,10,15,15,*');
sunday_grid.setColAlign("left,left,left,left,left,left,left,left,left");
sunday_grid.enableDragAndDrop(false);
sunday_grid.enableMercyDrag(false);
sunday_grid.setColTypes('ro,ed,ed,ed,ed,ed,ed,ed,ed');
sunday_grid.setDateFormat("%Y-%m-%d %H:%i:%s");
sunday_grid.setColSorting("int,str,str,str,str,str,str,str,str");
sunday_grid.enableSmartRendering("true");
sunday_grid.enableMultiselect(true);
sunday_grid.attachFooter("Totals,,,,,,,,,", "font-style:bold;font-weight:bold;text-align:right;background-color:transparent;");
sunday_grid.init();
var currentTime = new Date()
var month = currentTime.getMonth() + 1;
var year = currentTime.getFullYear()
sunday_grid.clearAndLoad("../data_sundays.php?action=4&month=" + month + "&year=" + year);
sunday_grid.attachEvent("onXLE", do_sunday_gridXLE);

function do_sunday_gridXLE(grid, count) {
    var i = sunday_grid.getSelectedRowId();
    if ((i == -1) || (i == null)) {
        i = 0;
    }
    sunday_grid.setSelectedRow(i);
    sunday_grid.selectRow(i);
}


//sunday grid select
sunday_grid.attachEvent("onSelectStateChanged", function (id) {
    var date = sunday_grid.cells(sunday_grid.getSelectedRowId(), 0).getValue();
    myBarCHart.load("../data_piechart.php?date=" + date);
});

//sunday form
var sunday_formStructure = [
    {type: "fieldset", name: "mydata", label: "Total Sunday Offering", height: myHeight * 0.9, offsetLeft: 5, list: [
            {type: "settings", position: "label-left", labelWidth: 80, inputWidth: 110, offsetLeft: 5},
            {type: "input", name: "id", label: "No", readonly: true},
            {type: "input", name: "date", label: "Date", readonly: true},
            {type: "input", name: "men", label: "Men"},
            {type: "input", name: "women", label: "Women"},
            {type: "input", name: "youth", label: "Youth"},
            {type: "newcolumn", offset: 20},
            {type: "input", name: "children", label: "Children"},
            {type: "input", name: "tithe", label: "Tithe"},
            {type: "input", name: "thanks", label: "Thanksgiving"},
            {type: "input", name: "seed", label: "Seed"},
            {type: "input", name: "total", label: "Total Amount", readonly: true}
        ]},
];
var sunday_Form = income_layout.cells("b").attachForm(sunday_formStructure);
sunday_Form.attachEvent("onFocus", function (name) {
    var men = sunday_Form.getItemValue('men');
    var women = sunday_Form.getItemValue('women');
    var youth = sunday_Form.getItemValue('youth');
    var children = sunday_Form.getItemValue('children');
    var tithe = sunday_Form.getItemValue('tithe');
    var thanks = sunday_Form.getItemValue('thanks');
    var seed = sunday_Form.getItemValue('seed');
    var total = sunday_Form.getItemValue('total');
    if (men == '0.00' && women == '0.00' && youth == '0.00' && children == '0.00' && tithe == '0.00' && thanks == '0.00' && seed == '0.00' && total == '0.00')
    {
        sunday_Form.setItemValue('men', '');
        sunday_Form.setItemValue('women', '');
        sunday_Form.setItemValue('youth', '');
        sunday_Form.setItemValue('children', '');
        sunday_Form.setItemValue('tithe', '');
        sunday_Form.setItemValue('thanks', '');
        sunday_Form.setItemValue('seed', '')
        sunday_Form.setItemValue('total', '');
    }
});

//sunday toolbar
sundayToolbar = income_layout.cells("a").attachToolbar();
sundayToolbar.addButton("new", 1, "<i class='fa fa-plus '></i>&nbsp;&nbsp;Add");
sundayToolbar.addButton("delete", 2, "<i class='fa fa-trash '></i>&nbsp;&nbsp;Remove");
sundayToolbar.addButton("refresh", 3, "<i class='fa fa-refresh fa-spin '></i>&nbsp;&nbsp;Refresh");
sundayToolbar.addButton("excell", 4, "<i class='fa fa-file-excel-o' aria-hidden='true'></i>&nbsp;&nbsp;Excell");
var month_opts = [
    ['Today', 'obj', 'Today'],
    ['sep01', 'sep', '', ''],
    ['01', 'obj', 'Jan'],
    ['sep01', 'sep', '', ''],
    ['02', 'obj', 'Feb'],
    ['sep01', 'sep', '', ''],
    ['03', 'obj', 'Mar'],
    ['sep01', 'sep', '', ''],
    ['04', 'obj', 'Apr', ],
    ['sep01', 'sep', '', ''],
    ['05', 'obj', 'May', ],
    ['sep01', 'sep', '', ''],
    ['06', 'obj', 'June', ],
    ['sep01', 'sep', '', ''],
    ['07', 'obj', 'Jul', ],
    ['sep01', 'sep', '', ''],
    ['08', 'obj', 'Aug', ],
    ['sep01', 'sep', '', ''],
    ['09', 'obj', 'Sep', ],
    ['sep01', 'sep', '', ''],
    ['10', 'obj', 'Oct', ],
    ['sep01', 'sep', '', ''],
    ['11', 'obj', 'Nov', ],
    ['sep01', 'sep', '', ''],
    ['12', 'obj', 'Dec', ],
    ['All', 'obj', 'All']
];
sundayToolbar.addButtonSelect("months", 5, "Choose Month", month_opts);

var year_opts = [
    ['2016', 'obj', '2016', ],
    ['sep01', 'sep', '', ''],
    ['2017', 'obj', '2017', ],
    ['sep01', 'sep', '', ''],
    ['2018', 'obj', '2018', ],
    ['sep01', 'sep', '', ''],
    ['2019', 'obj', '2019', ],
    ['sep01', 'sep', '', ''],
    ['2020', 'obj', '2020', ],
    ['sep01', 'sep', '', ''],
    ['2020', 'obj', '2021', ],
    ['sep01', 'sep', '', ''],
    ['2020', 'obj', '2022', ]
];

sundayToolbar.addButtonSelect("years", 6, "Choose Year", year_opts);

sundayToolbar.attachEvent("onClick", function (id)
{
    var selected_id = sunday_grid.getSelectedRowId();
    if (id == "new")
    {

        $.post("../data_sundays.php?action=1", function (data) {
            if (data.response)
            {
                dhtmlx.message({
                    text: "New record has been created!",
                    expire: 1000
                });
                sunday_grid.clearAndLoad("../data_sundays.php?action=4");
            }
        }, 'json');
    } else if (id == "delete")
    {
        dhtmlx.confirm({
            title: "Confirm",
            type: "confirm-warning",
            text: "Are you sure you  want to delete this record?",
            callback: function (y) {
                if (y)
                {

                    $.get("../data_sundays.php?action=2&id=" + selected_id, function (data) {
                        sunday_grid.deleteRow(selected_id);
                        dhtmlx.message(data.message);
                    }, 'json');
                } else
                {
                    return false;
                }
            }});
    } else if (id == "refresh")
    {
        sunday_grid.clearAndLoad("../data_sundays.php?action=4");
    }
    else if (id == "excell")
    {
        window.open("http://" + location.host + "/financials/Controller/excellfiles/income.php");
    }
     else if (sundayToolbar.getParentId(id) == "months")
    {
        sundayToolbar.setItemText("months", id);
        sunday_grid.clearAndLoad("../data_sundays.php?action=4&month=" + id);
    } else if (sundayToolbar.getParentId(id) == "years")
    {
        sundayToolbar.setItemText("years", id);
        sunday_grid.clearAndLoad("../data_sundays.php?action=4&year=" + id);


    }
});


sunday_grid.attachEvent("onEditCell", function (stage, rId, cInd, nValue, oValue) {
    var field = sunday_grid.getColumnId(cInd);
    var reg_no = sunday_grid.getSelectedRowId();
    var date = sunday_grid.cells(sunday_grid.getSelectedRowId(), 0).getValue();
    if (stage == 2)
    {
        $.post("../data_sundays.php?action=3", "&field=" + field + "&fieldvalue=" + nValue + "&id=" + rId, function (data) {
            if (data.data.success)
            {
                sunday_grid.cells(rId, cInd).setValue(nValue);
                setsunFooterSum(rId);
                sunday_grid.updateFromXML("../data_sundays.php?action=4");
                myBarCHart.load("../data_piechart.php?date=" + date);
            }
        }, 'json');
    }

});
sunday_grid.attachEvent("onSelectStateChanged", function (id) {
    //sunday_grid = id;
    sunday_Form.clear();
    sunday_Form.load("../data_sundays.php?action=6&id=" + id, function () {

    });
    setsunFooterSum(id);
});

function setsunFooterSum(id)
{
    $.get("../data_sundays.php?action=5&id=" + id, function (data) {
        if (data.data.success)
        {
            var men = data.data.men;
            var women = data.data.women;
            var youth = data.data.youth;
            var children = data.data.children;
            var tithe = data.data.tithe;
            var thanks = data.data.thanks;
            var seed = data.data.seed;
            var totals = data.data.totals;
            sunday_grid.setFooterLabel(1, '' + men);
            sunday_grid.setFooterLabel(2, '' + women);
            sunday_grid.setFooterLabel(3, '' + youth);
            sunday_grid.setFooterLabel(4, '' + children);
            sunday_grid.setFooterLabel(5, '' + tithe);
            sunday_grid.setFooterLabel(6, '' + thanks);
            sunday_grid.setFooterLabel(7, '' + seed);
            sunday_grid.setFooterLabel(8, '' + totals);
        }
    }, 'json');
}

//sunday toolbar
sundayformToolbar = income_layout.cells("b").attachToolbar();
sundayformToolbar.addButton("save", 1, "<i class='fa fa-floppy-o '></i> &nbsp;&nbsp; Save");

sundayformToolbar.attachEvent("onClick", function (id)
{

    if (id == "save")
    {
        var id = sunday_grid.getSelectedRowId();
        var date = sunday_grid.cells(sunday_grid.getSelectedRowId(), 0).getValue();
        sunday_Form.send("../data_sundays.php?action=7&id=" + id,
                function (loader, response)
                {
                    var data = eval('(' + response + ')');
                    if (data.success)
                    {
                        dhtmlx.message({
                            text: "Data  saved successfully !",
                            expire: 10000
                        });
                        sunday_grid.cells(sunday_grid.getSelectedRowId(), 0).setValue(data.date);
                        sunday_grid.cells(sunday_grid.getSelectedRowId(), 1).setValue(data.men);
                        sunday_grid.cells(sunday_grid.getSelectedRowId(), 2).setValue(data.women);
                        sunday_grid.cells(sunday_grid.getSelectedRowId(), 3).setValue(data.youth);
                        sunday_grid.cells(sunday_grid.getSelectedRowId(), 4).setValue(data.children);
                        sunday_grid.cells(sunday_grid.getSelectedRowId(), 5).setValue(data.tithe);
                        sunday_grid.cells(sunday_grid.getSelectedRowId(), 6).setValue(data.thanks);
                        sunday_grid.cells(sunday_grid.getSelectedRowId(), 7).setValue(data.seed);
                        sunday_grid.cells(sunday_grid.getSelectedRowId(), 8).setValue(data.totals);
                        setsunFooterSum(id);
                        sunday_Form.clear();
                        sunday_Form.load("../data_sundays.php?action=6&id=" + id, function () {

                        });
                        myBarCHart.load("../data_piechart.php?date=" + date);
                    } else
                    {

                    }
                }, 'json');
    }
});
var myBarCHart;
myBarCHart = sunday_main_layout.cells("a").attachChart({
    view: "bar",
    value: "#sales#",
    gradient: "falling",
    color: "#b9a8f9",
    radius: 0,
    alpha: 0.5,
    border: true,
    width: 70,
    xAxis: {
        template: "#year#",
        title: "Category",
    },
    yAxis: {
        title: "Collection in (%)",
        start: 0,
        end: 100,
        step: 10,
        template: function (obj) {
            return (obj % 20 ? "" : obj)
        }
    }
});
myBarCHart.load("../data_piechart.php");

//expenditures grid
expenditures_grid = expenditure_layout.cells("a").attachGrid();
expenditures_grid.setHeader('Date,Name,Amount,Person,Category');
expenditures_grid.setImagePath("http://" + location.host + "/Controller/include/dhtmlx6/skins/web/imgs/");
expenditures_grid.setColumnIds('Date,Name,Amount,Person,category');
expenditures_grid.attachHeader("#text_filter,#numeric_filter,#text_filter,#text_filter,#text_filter");
expenditures_grid.setSkin('dhx_web');
expenditures_grid.setInitWidthsP('0,*,20,20,10');
expenditures_grid.setColAlign("left,left,left,left,left");
expenditures_grid.enableDragAndDrop(false);
expenditures_grid.enableMercyDrag(false);
expenditures_grid.setColTypes('ro,ed,ed,ed,ed');
expenditures_grid.setDateFormat("%Y-%m-%d %H:%i:%s");
expenditures_grid.setColSorting("str,str,str,str,str");
expenditures_grid.enableSmartRendering("true");
expenditures_grid.enableMultiselect(true);
//expenditures_grid.attachFooter("Totals,,,,,", "font-style:bold;font-weight:bold;text-align:right;background-color:transparent;");
expenditures_grid.init();
var currentTime = new Date()
var month = currentTime.getMonth() + 1;
var year = currentTime.getFullYear()
expenditures_grid.clearAndLoad("../data_controller.php?action=41&month=" + month + "&year=" + year);
expenditures_grid.attachEvent("onXLE", doexpenditures_gridlistselectionXLE);

function doexpenditures_gridlistselectionXLE(grid, count) {
    var i = expenditures_grid.getSelectedRowId();
    if ((i == -1) || (i == null)) {
        i = 0;
    }
    expenditures_grid.setSelectedRow(i);
    expenditures_grid.selectRow(i);
}


expenditures_grid.attachEvent("onSelectStateChanged", function (id) {
    expenditure_Form.clear();
    expenditure_Form.load("../data_controller.php?action=46&id=" + id, function () { });
});

expenditures_Toolbar = expenditure_layout.cells("a").attachToolbar();
expenditures_Toolbar.addButton("new", 1, "<i class='fa fa-plus '></i>&nbsp;&nbsp;Add");
expenditures_Toolbar.addButton("delete", 2, "<i class='fa fa-trash '></i>&nbsp;&nbsp;Delete");
expenditures_Toolbar.addButton("excell", 3, "<i class='fa fa-file-excel-o' aria-hidden='true'></i>&nbsp;&nbsp;Excell");
var expenditure_opts = [
    ['25', 'obj', 'Men'],
    ['sep01', 'sep', '', ''],
    ['26', 'obj', 'Women'],
    ['sep01', 'sep', '', ''],
    ['23', 'obj', 'Youth'],
    ['sep01', 'sep', '', ''],
    ['24', 'obj', 'Children'],
    ['sep01', 'sep', '', ''],
    ['28', 'obj', 'Others', ],
];
expenditures_Toolbar.addButtonSelect("expenditures", 4, "Choose Category", expenditure_opts);

var month_opts = [
    ['Today', 'obj', 'Today'],
    ['sep01', 'sep', '', ''],
    ['01', 'obj', 'Jan'],
    ['sep01', 'sep', '', ''],
    ['02', 'obj', 'Feb'],
    ['sep01', 'sep', '', ''],
    ['03', 'obj', 'Mar'],
    ['sep01', 'sep', '', ''],
    ['04', 'obj', 'Apr', ],
    ['sep01', 'sep', '', ''],
    ['05', 'obj', 'May', ],
    ['sep01', 'sep', '', ''],
    ['06', 'obj', 'June', ],
    ['sep01', 'sep', '', ''],
    ['07', 'obj', 'Jul', ],
    ['sep01', 'sep', '', ''],
    ['08', 'obj', 'Aug', ],
    ['sep01', 'sep', '', ''],
    ['09', 'obj', 'Sep', ],
    ['sep01', 'sep', '', ''],
    ['10', 'obj', 'Oct', ],
    ['sep01', 'sep', '', ''],
    ['11', 'obj', 'Nov', ],
    ['sep01', 'sep', '', ''],
    ['12', 'obj', 'Dec', ],
    ['All', 'obj', 'All']
];
expenditures_Toolbar.addButtonSelect("months", 5, "Choose Month", month_opts);

var year_opts = [
    ['2016', 'obj', '2016', ],
    ['sep01', 'sep', '', ''],
    ['2017', 'obj', '2017', ],
    ['sep01', 'sep', '', ''],
    ['2018', 'obj', '2018', ],
    ['sep01', 'sep', '', ''],
    ['2019', 'obj', '2019', ],
    ['sep01', 'sep', '', ''],
    ['2020', 'obj', '2020', ],
    ['sep01', 'sep', '', ''],
    ['2020', 'obj', '2021', ],
    ['sep01', 'sep', '', ''],
    ['2020', 'obj', '2022', ]
];

expenditures_Toolbar.addButtonSelect("years", 6, "Choose Year", year_opts);
expenditures_Toolbar.attachEvent("onClick", function (id)
{
    var expense_id = expenditures_grid.getSelectedRowId();
    if (id == "new")
    {
        $.post("../data_controller.php?action=39", function (data) {
            if (data.response)
            {
                dhtmlx.message({
                    text: "New record has been created!",
                    expire: 1000
                });
                expenditures_grid.updateFromXML("../data_controller.php?action=41");
            }
        }, 'json');
    } else if (id == "delete")
    {
        dhtmlx.confirm({
            title: "Confirm",
            type: "confirm-warning",
            text: "Are you sure you  want to delete this record?",
            callback: function (y) {
                if (y)
                {

                    $.get("../data_controller.php?action=40&expense_id=" + expense_id, function (data) {
                        expenditures_grid.deleteRow(expense_id);
                        dhtmlx.message(data.message);
                    }, 'json');
                } else
                {
                    return false;
                }
            }});
    } 
    else if (id == "excell")
    {
        window.open("http://" + location.host + "/financials/Controller/excellfiles/expenditures.php");
    }
     else if (expenditures_Toolbar.getParentId(id) == "months")
    {
        expenditures_Toolbar.setItemText("months", id);
        expenditures_grid.clearAndLoad("../data_controller.php?action=41&month=" + id);
    } else if (expenditures_Toolbar.getParentId(id) == "years")
    {
        expenditures_Toolbar.setItemText("years", id);
        expenditures_grid.clearAndLoad("../data_controller.php?action=41&year=" + id);


    }
    else if (expenditures_Toolbar.getItemText("expenditures"))
    {
        expenditures_grid.clearAndLoad("../data_controller.php?action=47&category_id=" + id);
    }
});




//Expenditure form
var expenditure_formStructure = [
    {type: "fieldset", name: "mydata", label: "Expenditures", width: 550, offsetLeft: 5, list: [
            {type: "settings", position: "label-left", labelWidth: 80, inputWidth: 110, offsetLeft: 5},
            {type: "hidden", name: "id", label: "No", readonly: true},
            {type: "calendar", name: "date", label: "Date", readonly: true, dateFormat: "%Y-%m-%d"},
            {type: "input", name: "name", label: "Expenditure Name"},
            {type: "input", name: "amount", label: "Amount"},
            {type: "combo", name: "category", label: "Category"},
            {type: "combo", name: "person", label: "Person"},
            {type: "newcolumn", offset: 20},
            {type: 'editor', name: 'purpose', label: 'Purpose',
                labelLeft: 20, labelTop: 5, inputWidth: 200, inputLeft: 20, inputTop: 20,
                position: 'absolute', labelAlign: 'right', inputHeight: 180, value: ""},
        ]},
];
var expenditure_Form = expenditure_layout.cells("b").attachForm(expenditure_formStructure);

var categorycombo = expenditure_Form.getCombo("category");
categorycombo.enableAutocomplete();
categorycombo.enableFilteringMode(true);
categorycombo.clearAll();
categorycombo.load("../data_controller.php?action=38");

var personcombo = expenditure_Form.getCombo("person");
personcombo.enableAutocomplete();
personcombo.enableFilteringMode(true);
personcombo.clearAll();
personcombo.load("../data_controller.php?action=31")
//sunday toolbar
expendituresformToolbar = expenditure_layout.cells("b").attachToolbar();
expendituresformToolbar.addButton("save", 1, "<i class='fa fa-floppy-o '></i> &nbsp;&nbsp; Save");

expendituresformToolbar.attachEvent("onClick", function (id)
{

    if (id == "save")
    {
        var expense_id = expenditures_grid.getSelectedRowId();
        expenditure_Form.send("../data_controller.php?action=45&expense_id=" + expense_id,
                function (loader, response)
                {
                    var data = eval('(' + response + ')');

                    if (data.success = 'true')
                    {

                        dhtmlx.message({
                            text: "Data  saved successfully !",
                            expire: 10000
                        });
                        expenditures_grid.cells(expenditures_grid.getSelectedRowId(), 1).setValue(data.name);
                        expenditures_grid.cells(expenditures_grid.getSelectedRowId(), 2).setValue(data.amount);
                        expenditures_grid.cells(expenditures_grid.getSelectedRowId(), 3).setValue(data.person);
                        expenditures_grid.cells(expenditures_grid.getSelectedRowId(), 4).setValue(data.category);
                    }
                }, 'json');


    }
});

//account toolbar
accountToolbar = sunday_tab.cells("account").attachToolbar();
accountToolbar.addButton("refresh", 1, "<i class='fa fa-refresh fa-spin' aria-hidden='true'></i>&nbsp;&nbsp;Refresh");
accountToolbar.addButton("excell", 2, "<i class='fa fa-file-excel-o' aria-hidden='true'></i>&nbsp;&nbsp;Export");
var month_opts = [
    ['Today', 'obj', 'Today'],
    ['sep01', 'sep', '', ''],
    ['01', 'obj', 'Jan'],
    ['sep01', 'sep', '', ''],
    ['02', 'obj', 'Feb'],
    ['sep01', 'sep', '', ''],
    ['03', 'obj', 'Mar'],
    ['sep01', 'sep', '', ''],
    ['04', 'obj', 'Apr', ],
    ['sep01', 'sep', '', ''],
    ['05', 'obj', 'May', ],
    ['sep01', 'sep', '', ''],
    ['06', 'obj', 'June', ],
    ['sep01', 'sep', '', ''],
    ['07', 'obj', 'Jul', ],
    ['sep01', 'sep', '', ''],
    ['08', 'obj', 'Aug', ],
    ['sep01', 'sep', '', ''],
    ['09', 'obj', 'Sep', ],
    ['sep01', 'sep', '', ''],
    ['10', 'obj', 'Oct', ],
    ['sep01', 'sep', '', ''],
    ['11', 'obj', 'Nov', ],
    ['sep01', 'sep', '', ''],
    ['12', 'obj', 'Dec', ],
    ['All', 'obj', 'All']
];
accountToolbar.addButtonSelect("months", 3, "Choose Month", month_opts);

var year_opts = [
    ['2016', 'obj', '2016', ],
    ['sep01', 'sep', '', ''],
    ['2017', 'obj', '2017', ],
    ['sep01', 'sep', '', ''],
    ['2018', 'obj', '2018', ],
    ['sep01', 'sep', '', ''],
    ['2019', 'obj', '2019', ],
    ['sep01', 'sep', '', ''],
    ['2020', 'obj', '2020', ],
    ['sep01', 'sep', '', ''],
    ['2020', 'obj', '2021', ],
    ['sep01', 'sep', '', ''],
    ['2020', 'obj', '2022', ]
];

accountToolbar.addButtonSelect("years", 4, "Choose Year", year_opts);

accountToolbar.attachEvent("onClick", function (id)
{

    if (id == "refresh")
    {
        account_grid.clearAndLoad("../data_controller.php?action=48");
    } else if (id == "excell")
    {
        window.open("http://" + location.host + "/financials/Controller/excellfiles/account.php");
    }
     else if (accountToolbar.getParentId(id) == "months")
    {
        accountToolbar.setItemText("months", id);
        account_grid.clearAndLoad("../data_controller.php?action=48&month=" + id);
    } else if (accountToolbar.getParentId(id) == "years")
    {
        accountToolbar.setItemText("years", id);
        account_grid.clearAndLoad("../data_controller.php?action=48&year=" + id);


    }
});
//account grid
account_grid = sunday_tab.cells("account").attachGrid();
account_grid.setHeader('Date,Men,Women,Youth,Children,Total');
account_grid.setImagePath("http://" + location.host + "/Controller/include/dhtmlx6/skins/web/imgs/");
account_grid.setColumnIds('date,men,women,youth,children,total');
account_grid.attachHeader("#text_filter,#numeric_filter,#numeric_filter,#numeric_filter,#numeric_filter,#text_filter");
account_grid.setSkin('dhx_web');
account_grid.setInitWidthsP('*,10,10,10,10,10');
account_grid.setColAlign("left,left,left,left,left,left");
account_grid.enableDragAndDrop(false);
account_grid.enableMercyDrag(false);
account_grid.setColTypes('ro,ed,ed,ed,ed,ed');
account_grid.setDateFormat("%Y-%m-%d %H:%i:%s");
account_grid.setColSorting("int,str,str,str,str,str");
account_grid.enableSmartRendering("true");
account_grid.enableMultiselect(true);
//account_grid.attachFooter("Totals,,,,,,", "font-style:bold;font-weight:bold;text-align:right;background-color:transparent;");
account_grid.init();
var currentTime = new Date()
var month = currentTime.getMonth() + 1;
var year = currentTime.getFullYear()
account_grid.clearAndLoad("../data_controller.php?action=48&month=" + month + "&year=" + year);
account_grid.attachEvent("onXLE", doaccountXLE);

function doaccountXLE(grid, count) {
    var i = account_grid.getSelectedRowId();
    if ((i == -1) || (i == null)) {
        i = 0;
    }
    account_grid.setSelectedRow(i);
    account_grid.selectRow(i);
}
function setFooterSum(id)
{
    $.get("../data_controller.php?action=12", function (data) {
        if (data.data.success)
        {
            var first_fruit = data.data.men;
            var love_offering = data.data.women;
            var evangelism = data.data.youth;
            var blessings = data.data.children;
            var others = data.data.total;
            account_grid.setFooterLabel(1, '' + others);
            account_grid.setFooterLabel(2, '' + first_fruit);
            account_grid.setFooterLabel(3, '' + love_offering);
            account_grid.setFooterLabel(4, '' + evangelism);
            account_grid.setFooterLabel(5, '' + blessings);
            account_grid.setFooterLabel(6, '' + others);
        }
    }, 'json');
}

var access = document.getElementById("accessrights").value;
if (access == 2)
{
    sundayToolbar.hideItem("delete");
    sundayToolbar.hideItem("new");
    expendituresformToolbar.hideItem("save");
    expenditures_Toolbar.hideItem("delete");
    expenditures_Toolbar.hideItem("add");
    sundayformToolbar.hideItem("save");
    expenditures_grid.enableEditEvents(false, false, false);
    sunday_grid.enableEditEvents(false, false, false);


} 