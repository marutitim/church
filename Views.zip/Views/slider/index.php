
<?php
 require_once '../../Controller/config/config.php';
$path="http://". filter_input(INPUT_SERVER, 'HTTP_HOST')."/";
?>
<script type="text/javascript" src="js/jssor.core.js"></script>
<script type="text/javascript" src="js/jssor.utils.js"></script>
<script type="text/javascript" src="js/jssor.slider.js"></script>
<script>
    jssor_slider1_starter = function(containerId) {
        var options = {
            $AutoPlay: false,
            $SlideDuration: 800,
            $ThumbnailNavigatorOptions: {
                $Class: $JssorThumbnailNavigator$,
                $ChanceToShow: 2,
                $ActionMode: 1,
                $SpacingX: 8,
                $DisplayPieces: 10,
                $ParkingPosition: 360
            }
        };

        var jssor_slider1 = new $JssorSlider$(containerId, options);
    };
</script>

<div id="slider1_container" style="
     
 position: relative; top: 0px; left: 30px; width:400;
 height: 356px; background: #24262e; overflow: hidden;
-webkit-border-radius:5px;
-moz-border-radius:5px;
 border-radius:5px;
">

    <!-- Loading Screen -->
    <div u="loading" style="position: absolute; top: 0px; left: 0px;">
        <div style="filter: alpha(opacity=70); opacity:0.7; position: absolute; display: block;
             background-color: #000000; top: 0px; left: 0px;width: 100%;height:100%;">
        </div>
        <div style="position: absolute; display: block; background: url(slider/img/loading.gif) no-repeat center center;
             top: 0px; left: 0px;width: 100%;height:100%;">
        </div>
    </div>

    <!-- Slides Container -->
    <div u="slides" style="cursor: move; position: relative; left: 0px; top: 0px; width:500px; height: 450px; overflow: hidden;">
    
        <?php
        $select = "SELECT image FROM assests WHERE id={$_GET['id']} ";
        $result = mysqli_query($con,$select) or die($select . mysql_error($con));
        $rowcheck=mysqli_num_rows($result);
        
        
        if($rowcheck>0){
        while ($row = mysqli_fetch_array($result)) {  
            echo " <div> " .
            ' <img u = "image" src = "'.$path.'/financials/Controller/assets_pic/2016/' . $row['image'] . '"  width="300" height="400" />' .
           '<img u = "thumb" src = "'.$path.'/financials/Controller/assets_pic/2016/' . $row['image'] . '" width="300" height="400" />' .
            ' </div>';      
            }
        }
     else {
           echo " <div> " .
            ' <img u = "image" src = "'.$path.'/financials/Controller/assets_pic/2016/noimage.png"  width="300" height="300"/>' .
           '<img u = "thumb" src = "'.$path.'/financials/Controller/assets_pic/2016/noimage.png" width="300" height="300" />' .
           ' </div>';      
       
        }
        ?>
    </div>

    <!-- Thumbnail Navigator Skin Begin -->
    <div u="thumbnavigator" class="jssort01" style="position: absolute; width: 400px; height: 100px; left:0px; bottom: 0px;">

        <!-- Thumbnail Item Skin Begin -->
        <style>
            /* jssor slider thumbnail navigator skin 01 css */
            /*
            .jssort01 .p           (normal)
            .jssort01 .p:hover     (normal mouseover)
            .jssort01 .pav           (active)
            .jssort01 .pav:hover     (active mouseover)
            .jssort01 .pdn           (mousedown)
            */
            .jssort01 .w
            {
                position: absolute;
                top: 0px;
                left: 0px;
                width: 100%;
                height: 100%;
            }
            .jssort01 .c {
                position: absolute;
                top: 0px;
                left: 0px;
                width: 68px;
                height: 68px;
                border: #000 2px solid;
            }
            .jssort01 .p:hover .c, .jssort01 .pav:hover .c, .jssort01 .pav .c {
                background: url(slider/img/t01.png) center center;
                border-width: 0px;
                top: 2px;
                left: 2px;
                width: 68px;
                height: 68px;
            }
            .jssort01 .p:hover .c, .jssort01 .pav:hover .c {
                top: 0px;
                left: 0px;
                width: 70px;
                height: 70px;
                border: #fff 1px solid;
            }
        </style>
        <div u="slides" style="cursor: move;">
            <div u="prototype" class="p" style="top: 0; left: 0;">
     <div class=w><thumbnailtemplate style="width: 100%; height: 100%; border: none;position:absolute; top: 0; left: 0;"></thumbnailtemplate></div>
                <div class=c>
                </div>
            </div>
        </div>
        <!-- Thumbnail Item Skin End -->
    </div>
    <!-- Trigger -->
    <script>
        jssor_slider1_starter('slider1_container');
    </script>
</div>